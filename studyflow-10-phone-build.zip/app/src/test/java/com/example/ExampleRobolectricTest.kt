package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.QuestionPaperEntity
import com.example.data.repository.BackupManager
import com.example.data.repository.StudyFlowBackup
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context verifies StudyFlow 10 app name`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("StudyFlow 10", appName)
    }

    @Test
    fun `question paper percentage calculation is accurate`() {
        val paper = QuestionPaperEntity(
            subjectId = "MATH",
            paperName = "CBSE Sample Paper 01",
            maxMarks = 80.0,
            obtainedMarks = 68.0,
            status = QuestionPaperEntity.STATUS_COMPLETED
        )
        assertNotNull(paper.percentage)
        assertEquals(85.0, paper.percentage!!, 0.001)
    }

    @Test
    fun `backup manager exports and parses valid json`() {
        val backup = StudyFlowBackup(
            exportTimestamp = 1700000000000L,
            appVersion = "1.0",
            studentName = "Pranav",
            homeworkList = emptyList(),
            subjects = emptyList(),
            chapters = emptyList(),
            tasks = emptyList(),
            questionPapers = emptyList()
        )
        val json = BackupManager.exportToJson(backup)
        assertTrue(json.contains("StudyFlow 10"))
        assertTrue(json.contains("Pranav"))

        val parsed = BackupManager.parseBackupJson(json)
        assertTrue(parsed.isSuccess)
        assertEquals("Pranav", parsed.getOrNull()?.studentName)
    }
}
