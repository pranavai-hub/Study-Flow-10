package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.unit.dp
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Assignment
import androidx.compose.material.icons.outlined.AutoStories
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.QuestionPaperEntity
import com.example.ui.components.AddChapterDialog
import com.example.ui.components.AddHomeworkDialog
import com.example.ui.components.AddQuestionPaperDialog
import com.example.ui.screens.AnalyticsScreen
import com.example.ui.screens.ChaptersScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.HomeworkScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.QuestionPapersScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.StudyFlowTheme
import com.example.ui.viewmodel.StudyFlowViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class AppNavSection {
    DASHBOARD,
    HOMEWORK,
    CHAPTERS,
    PAPERS,
    ANALYTICS,
    SETTINGS
}

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val viewModel: StudyFlowViewModel = viewModel()
            val userPrefs by viewModel.userPreferences.collectAsStateWithLifecycle()

            StudyFlowTheme(themePreference = userPrefs.themeMode) {
                if (!userPrefs.isOnboarded) {
                    OnboardingScreen(
                        onContinue = { enteredName ->
                            viewModel.completeOnboarding(enteredName)
                        }
                    )
                } else {
                    MainAppShell(viewModel = viewModel)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppShell(viewModel: StudyFlowViewModel) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    var currentSection by remember { mutableStateOf(AppNavSection.DASHBOARD) }
    var previousSection by remember { mutableStateOf(AppNavSection.DASHBOARD) }

    // Dialog States
    var showAddHomeworkDialog by remember { mutableStateOf(false) }
    var showAddChapterDialog by remember { mutableStateOf<Pair<String, String>?>(null) } // (id, name)
    var showAddPaperDialog by remember { mutableStateOf<String?>(null) } // defaultSubjectId
    var editingPaper by remember { mutableStateOf<QuestionPaperEntity?>(null) }

    // State Collection
    val userPrefs by viewModel.userPreferences.collectAsStateWithLifecycle()
    val allHomework by viewModel.allHomework.collectAsStateWithLifecycle()
    val pendingHomework by viewModel.pendingHomework.collectAsStateWithLifecycle()
    val completedHomework by viewModel.completedHomework.collectAsStateWithLifecycle()
    val subjects by viewModel.subjects.collectAsStateWithLifecycle()
    val chapters by viewModel.chapters.collectAsStateWithLifecycle()
    val chapterTasks by viewModel.chapterTasks.collectAsStateWithLifecycle()
    val questionPapers by viewModel.questionPapers.collectAsStateWithLifecycle()
    val completedPapers by viewModel.completedPapers.collectAsStateWithLifecycle()
    val subjectProgressList by viewModel.subjectProgressList.collectAsStateWithLifecycle()
    val overallChapterProgress by viewModel.overallChapterProgress.collectAsStateWithLifecycle()
    val overallAverageScore by viewModel.overallAverageScore.collectAsStateWithLifecycle()
    val bestScore by viewModel.bestScore.collectAsStateWithLifecycle()
    val latestScore by viewModel.latestScore.collectAsStateWithLifecycle()
    val scoreDelta by viewModel.scoreDeltaFromPrevious.collectAsStateWithLifecycle()
    val subjectScoreStats by viewModel.subjectScoreStats.collectAsStateWithLifecycle()
    val suggestions by viewModel.studySuggestions.collectAsStateWithLifecycle()

    // Notification Permission Request (Android 13+)
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val isGranted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!isGranted) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    // SAF File Pickers for Backup & Restore
    val exportBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch {
                try {
                    val json = viewModel.exportBackupJson()
                    withContext(Dispatchers.IO) {
                        context.contentResolver.openOutputStream(uri)?.use { os ->
                            os.write(json.toByteArray(Charsets.UTF_8))
                        }
                    }
                    snackbarHostState.showSnackbar("Backup successfully exported to JSON file!")
                } catch (e: Exception) {
                    snackbarHostState.showSnackbar("Export failed: ${e.localizedMessage}")
                }
            }
        }
    }

    val importBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch {
                try {
                    val json = withContext(Dispatchers.IO) {
                        context.contentResolver.openInputStream(uri)?.use { stream ->
                            stream.bufferedReader(Charsets.UTF_8).readText()
                        }
                    }
                    if (json != null) {
                        val result = viewModel.importBackupJson(json, replaceExisting = true)
                        if (result.isSuccess) {
                            snackbarHostState.showSnackbar("Backup successfully restored!")
                        } else {
                            snackbarHostState.showSnackbar("Import failed: ${result.exceptionOrNull()?.localizedMessage}")
                        }
                    }
                } catch (e: Exception) {
                    snackbarHostState.showSnackbar("Import failed: ${e.localizedMessage}")
                }
            }
        }
    }

    // Android Back button handling
    BackHandler(enabled = currentSection != AppNavSection.DASHBOARD) {
        currentSection = if (currentSection == AppNavSection.SETTINGS) {
            previousSection
        } else {
            AppNavSection.DASHBOARD
        }
    }

    // Dialogs
    if (showAddHomeworkDialog) {
        val subjectNames = subjects.map { it.name }.ifEmpty { listOf("Mathematics", "Science", "SST", "English", "Hindi", "AI") }
        AddHomeworkDialog(
            subjects = subjectNames,
            onAddHomework = { title, subject, notes, dueDate ->
                viewModel.addHomework(title, subject, notes, dueDate)
                coroutineScope.launch {
                    snackbarHostState.showSnackbar("Homework added!")
                }
            },
            onDismiss = { showAddHomeworkDialog = false }
        )
    }

    if (showAddChapterDialog != null) {
        val (subId, subName) = showAddChapterDialog!!
        AddChapterDialog(
            subjectName = subName,
            onAddChapter = { name, chapterNumber, notes ->
                viewModel.addChapter(subId, name, chapterNumber, notes)
                coroutineScope.launch {
                    snackbarHostState.showSnackbar("Chapter added to $subName with 7 checklist items!")
                }
            },
            onDismiss = { showAddChapterDialog = null }
        )
    }

    if (showAddPaperDialog != null) {
        val subjectPairs = subjects.map { Pair(it.id, it.name) }
        AddQuestionPaperDialog(
            defaultSubjectId = showAddPaperDialog!!,
            subjects = subjectPairs,
            onAddPaper = { subjectId, paperName, maxMarks, obtainedMarks, duration, notes, status ->
                viewModel.addQuestionPaper(
                    subjectId = subjectId,
                    paperName = paperName,
                    maxMarks = maxMarks,
                    obtainedMarks = obtainedMarks,
                    duration = duration,
                    notes = notes,
                    status = status
                )
                coroutineScope.launch {
                    snackbarHostState.showSnackbar("Question paper recorded!")
                }
            },
            onDismiss = { showAddPaperDialog = null }
        )
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = when (currentSection) {
                            AppNavSection.DASHBOARD -> "StudyFlow 10"
                            AppNavSection.HOMEWORK -> "Homework"
                            AppNavSection.CHAPTERS -> "Chapters"
                            AppNavSection.PAPERS -> "Question Papers"
                            AppNavSection.ANALYTICS -> "Analytics"
                            AppNavSection.SETTINGS -> "Settings"
                        },
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    if (currentSection == AppNavSection.SETTINGS) {
                        IconButton(onClick = { currentSection = previousSection }) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back"
                            )
                        }
                    }
                },
                actions = {
                    if (currentSection != AppNavSection.SETTINGS) {
                        IconButton(
                            onClick = {
                                previousSection = currentSection
                                currentSection = AppNavSection.SETTINGS
                            },
                            modifier = Modifier.testTag("open_settings_button")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Settings,
                                contentDescription = "Settings"
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onBackground
                )
            )
        },
        bottomBar = {
            if (currentSection != AppNavSection.SETTINGS) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 3.dp,
                    modifier = Modifier.testTag("main_bottom_nav")
                ) {
                    NavigationBarItem(
                        selected = currentSection == AppNavSection.DASHBOARD,
                        onClick = { currentSection = AppNavSection.DASHBOARD },
                        icon = {
                            Icon(
                                imageVector = if (currentSection == AppNavSection.DASHBOARD) Icons.Filled.Dashboard else Icons.Outlined.Dashboard,
                                contentDescription = "Dashboard"
                            )
                        },
                        label = { Text("Dashboard") }
                    )

                    NavigationBarItem(
                        selected = currentSection == AppNavSection.HOMEWORK,
                        onClick = { currentSection = AppNavSection.HOMEWORK },
                        icon = {
                            Icon(
                                imageVector = if (currentSection == AppNavSection.HOMEWORK) Icons.Filled.Assignment else Icons.Outlined.Assignment,
                                contentDescription = "Homework"
                            )
                        },
                        label = { Text("Homework") }
                    )

                    NavigationBarItem(
                        selected = currentSection == AppNavSection.CHAPTERS,
                        onClick = { currentSection = AppNavSection.CHAPTERS },
                        icon = {
                            Icon(
                                imageVector = if (currentSection == AppNavSection.CHAPTERS) Icons.Filled.AutoStories else Icons.Outlined.AutoStories,
                                contentDescription = "Chapters"
                            )
                        },
                        label = { Text("Chapters") }
                    )

                    NavigationBarItem(
                        selected = currentSection == AppNavSection.PAPERS,
                        onClick = { currentSection = AppNavSection.PAPERS },
                        icon = {
                            Icon(
                                imageVector = if (currentSection == AppNavSection.PAPERS) Icons.Filled.Description else Icons.Outlined.Description,
                                contentDescription = "Papers"
                            )
                        },
                        label = { Text("Papers") }
                    )

                    NavigationBarItem(
                        selected = currentSection == AppNavSection.ANALYTICS,
                        onClick = { currentSection = AppNavSection.ANALYTICS },
                        icon = {
                            Icon(
                                imageVector = if (currentSection == AppNavSection.ANALYTICS) Icons.Filled.BarChart else Icons.Outlined.BarChart,
                                contentDescription = "Analytics"
                            )
                        },
                        label = { Text("Analytics") }
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentSection) {
                AppNavSection.DASHBOARD -> {
                    DashboardScreen(
                        studentName = userPrefs.studentName,
                        allHomework = allHomework,
                        pendingHomework = pendingHomework,
                        completedHomework = completedHomework,
                        overallChapterProgress = overallChapterProgress,
                        questionPapers = questionPapers,
                        subjectProgressList = subjectProgressList,
                        onToggleHomework = { viewModel.toggleHomework(it) },
                        onQuickAddHomework = { showAddHomeworkDialog = true },
                        onQuickAddChapter = {
                            val firstSub = subjects.firstOrNull()
                            showAddChapterDialog = Pair(firstSub?.id ?: "MATH", firstSub?.name ?: "Mathematics")
                        },
                        onQuickAddPaper = {
                            showAddPaperDialog = subjects.firstOrNull()?.id ?: "MATH"
                        },
                        onNavigateToHomework = { currentSection = AppNavSection.HOMEWORK },
                        onNavigateToChapters = { currentSection = AppNavSection.CHAPTERS },
                        onNavigateToPapers = { currentSection = AppNavSection.PAPERS },
                        onNavigateToAnalytics = { currentSection = AppNavSection.ANALYTICS }
                    )
                }

                AppNavSection.HOMEWORK -> {
                    HomeworkScreen(
                        allHomework = allHomework,
                        pendingHomework = pendingHomework,
                        completedHomework = completedHomework,
                        onToggleHomework = { viewModel.toggleHomework(it) },
                        onDeleteHomework = { viewModel.deleteHomework(it) },
                        onNewHomeworkClick = { showAddHomeworkDialog = true }
                    )
                }

                AppNavSection.CHAPTERS -> {
                    ChaptersScreen(
                        subjects = subjects,
                        chapters = chapters,
                        tasks = chapterTasks,
                        subjectProgressList = subjectProgressList,
                        onToggleTask = { viewModel.toggleChapterTask(it) },
                        onResetChapterChecklist = { viewModel.resetChapterChecklist(it) },
                        onDeleteChapter = { viewModel.deleteChapter(it) },
                        onAddChapterClick = { id, name ->
                            showAddChapterDialog = Pair(id, name)
                        }
                    )
                }

                AppNavSection.PAPERS -> {
                    QuestionPapersScreen(
                        subjects = subjects,
                        questionPapers = questionPapers,
                        onAddPaperClick = { subId ->
                            showAddPaperDialog = subId
                        },
                        onDeletePaper = { viewModel.deleteQuestionPaper(it) },
                        onEditPaper = { paper ->
                            showAddPaperDialog = paper.subjectId
                        }
                    )
                }

                AppNavSection.ANALYTICS -> {
                    AnalyticsScreen(
                        overallAverageScore = overallAverageScore,
                        bestScore = bestScore,
                        latestScore = latestScore,
                        scoreDelta = scoreDelta,
                        completedPapers = completedPapers,
                        overallChapterProgress = overallChapterProgress,
                        subjectProgressList = subjectProgressList,
                        subjectScoreStats = subjectScoreStats,
                        suggestions = suggestions
                    )
                }

                AppNavSection.SETTINGS -> {
                    SettingsScreen(
                        userPreferences = userPrefs,
                        onUpdateStudentName = { viewModel.updateStudentName(it) },
                        onUpdateTheme = { viewModel.updateTheme(it) },
                        onUpdateReminder = { enabled, h, m ->
                            viewModel.updateReminderSettings(enabled, h, m)
                            coroutineScope.launch {
                                snackbarHostState.showSnackbar("Reminder settings updated!")
                            }
                        },
                        onExportBackup = {
                            val filename = "studyflow10_backup_${System.currentTimeMillis()}.json"
                            exportBackupLauncher.launch(filename)
                        },
                        onImportBackup = {
                            importBackupLauncher.launch(arrayOf("application/json"))
                        },
                        onResetAllData = {
                            viewModel.resetAllData()
                            currentSection = AppNavSection.DASHBOARD
                            coroutineScope.launch {
                                snackbarHostState.showSnackbar("All data reset to factory syllabus state.")
                            }
                        }
                    )
                }
            }
        }
    }
}
