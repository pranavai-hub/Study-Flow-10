package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.ChapterDao
import com.example.data.dao.HomeworkDao
import com.example.data.dao.QuestionPaperDao
import com.example.data.dao.SubjectDao
import com.example.data.model.CbseSyllabusData
import com.example.data.model.ChapterEntity
import com.example.data.model.ChapterTaskEntity
import com.example.data.model.HomeworkEntity
import com.example.data.model.QuestionPaperEntity
import com.example.data.model.SubjectEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        HomeworkEntity::class,
        SubjectEntity::class,
        ChapterEntity::class,
        ChapterTaskEntity::class,
        QuestionPaperEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class StudyFlowDatabase : RoomDatabase() {
    abstract fun homeworkDao(): HomeworkDao
    abstract fun subjectDao(): SubjectDao
    abstract fun chapterDao(): ChapterDao
    abstract fun questionPaperDao(): QuestionPaperDao

    companion object {
        @Volatile
        private var INSTANCE: StudyFlowDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope = CoroutineScope(Dispatchers.IO)): StudyFlowDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    StudyFlowDatabase::class.java,
                    "studyflow10_database.db"
                )
                    .fallbackToDestructiveMigration(dropAllTables = true)
                    .addCallback(DatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialSyllabus(database)
                    }
                }
            }
        }

        suspend fun populateInitialSyllabus(database: StudyFlowDatabase) {
            val subjectDao = database.subjectDao()
            val chapterDao = database.chapterDao()

            // Always upsert the 7 CBSE subject definitions so names/order stay accurate
            val subjectEntities = CbseSyllabusData.SUBJECTS.map { defaultSub ->
                SubjectEntity(
                    id = defaultSub.id,
                    name = defaultSub.name,
                    iconName = defaultSub.iconName,
                    displayOrder = defaultSub.displayOrder
                )
            }
            subjectDao.insertSubjects(subjectEntities)

            val existingChapters = chapterDao.getAllChaptersList()

            // For each subject, if it has 0 chapters or is missing the new 2026-27 sections, sync chapters safely
            for (defaultSub in CbseSyllabusData.SUBJECTS) {
                val subjectExisting = existingChapters.filter { it.subjectId == defaultSub.id }
                if (subjectExisting.isEmpty()) {
                    for (defaultChap in defaultSub.defaultChapters) {
                        val chapterEntity = ChapterEntity(
                            subjectId = defaultSub.id,
                            chapterNumber = defaultChap.chapterNumber,
                            name = defaultChap.name,
                            notes = defaultChap.section
                        )
                        val chapterId = chapterDao.insertChapter(chapterEntity)

                        val tasks = ChapterTaskEntity.ALL_TASK_TYPES.map { taskType ->
                            ChapterTaskEntity(
                                chapterId = chapterId,
                                taskType = taskType,
                                isCompleted = false
                            )
                        }
                        chapterDao.insertTasks(tasks)
                    }
                } else {
                    // Ensure any missing default chapters from the 2026-27 syllabus are added without deleting user task progress
                    val existingNames = subjectExisting.map { it.name.lowercase().trim() }.toSet()
                    for (defaultChap in defaultSub.defaultChapters) {
                        if (!existingNames.contains(defaultChap.name.lowercase().trim())) {
                            val chapterEntity = ChapterEntity(
                                subjectId = defaultSub.id,
                                chapterNumber = defaultChap.chapterNumber,
                                name = defaultChap.name,
                                notes = defaultChap.section
                            )
                            val chapterId = chapterDao.insertChapter(chapterEntity)
                            val tasks = ChapterTaskEntity.ALL_TASK_TYPES.map { taskType ->
                                ChapterTaskEntity(
                                    chapterId = chapterId,
                                    taskType = taskType,
                                    isCompleted = false
                                )
                            }
                            chapterDao.insertTasks(tasks)
                        }
                    }
                }
            }
        }
    }
}
