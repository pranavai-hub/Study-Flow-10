package com.example.data.model

object CbseSyllabusData {

    data class DefaultChapter(
        val chapterNumber: Int,
        val name: String,
        val section: String = ""
    )

    data class DefaultSubject(
        val id: String,
        val name: String,
        val iconName: String,
        val displayOrder: Int,
        val defaultChapters: List<DefaultChapter>
    )

    val SUBJECTS = listOf(
        DefaultSubject(
            id = "SCIENCE",
            name = "Science (NCERT)",
            iconName = "science",
            displayOrder = 1,
            defaultChapters = listOf(
                // CHEMISTRY
                DefaultChapter(1, "Chemical Reactions and Equations", "CHEMISTRY"),
                DefaultChapter(2, "Acids, Bases and Salts", "CHEMISTRY"),
                DefaultChapter(3, "Metals and Non-metals", "CHEMISTRY"),
                DefaultChapter(4, "Carbon and Its Compounds", "CHEMISTRY"),
                // BIOLOGY
                DefaultChapter(5, "Life Processes", "BIOLOGY"),
                DefaultChapter(6, "Control and Coordination", "BIOLOGY"),
                DefaultChapter(7, "How do Organisms Reproduce?", "BIOLOGY"),
                DefaultChapter(8, "Heredity", "BIOLOGY"),
                // PHYSICS
                DefaultChapter(9, "Light – Reflection and Refraction", "PHYSICS"),
                DefaultChapter(10, "The Human Eye and the Colourful World", "PHYSICS"),
                DefaultChapter(11, "Electricity", "PHYSICS"),
                DefaultChapter(12, "Magnetic Effects of Electric Current", "PHYSICS"),
                // ENVIRONMENT
                DefaultChapter(13, "Our Environment", "ENVIRONMENT")
            )
        ),
        DefaultSubject(
            id = "MATH",
            name = "Mathematics (NCERT)",
            iconName = "calculate",
            displayOrder = 2,
            defaultChapters = listOf(
                DefaultChapter(1, "Real Numbers", "NCERT"),
                DefaultChapter(2, "Polynomials", "NCERT"),
                DefaultChapter(3, "Pair of Linear Equations in Two Variables", "NCERT"),
                DefaultChapter(4, "Quadratic Equations", "NCERT"),
                DefaultChapter(5, "Arithmetic Progressions", "NCERT"),
                DefaultChapter(6, "Triangles", "NCERT"),
                DefaultChapter(7, "Coordinate Geometry", "NCERT"),
                DefaultChapter(8, "Introduction to Trigonometry", "NCERT"),
                DefaultChapter(9, "Some Applications of Trigonometry", "NCERT"),
                DefaultChapter(10, "Circles", "NCERT"),
                DefaultChapter(11, "Areas Related to Circles", "NCERT"),
                DefaultChapter(12, "Surface Areas and Volumes", "NCERT"),
                DefaultChapter(13, "Statistics", "NCERT"),
                DefaultChapter(14, "Probability", "NCERT")
            )
        ),
        DefaultSubject(
            id = "SST",
            name = "Social Science (SST)",
            iconName = "public",
            displayOrder = 3,
            defaultChapters = listOf(
                // HISTORY
                DefaultChapter(1, "The Rise of Nationalism in Europe", "HISTORY"),
                DefaultChapter(2, "Nationalism in India", "HISTORY"),
                DefaultChapter(3, "The Making of a Global World", "HISTORY"),
                DefaultChapter(4, "The Age of Industrialisation", "HISTORY"),
                DefaultChapter(5, "Print Culture and the Modern World", "HISTORY"),
                // GEOGRAPHY
                DefaultChapter(1, "Resources and Development", "GEOGRAPHY"),
                DefaultChapter(2, "Forest and Wildlife Resources", "GEOGRAPHY"),
                DefaultChapter(3, "Water Resources", "GEOGRAPHY"),
                DefaultChapter(4, "Agriculture", "GEOGRAPHY"),
                DefaultChapter(5, "Minerals and Energy Resources", "GEOGRAPHY"),
                DefaultChapter(6, "Manufacturing Industries", "GEOGRAPHY"),
                DefaultChapter(7, "Lifelines of National Economy", "GEOGRAPHY"),
                // POLITICAL SCIENCE
                DefaultChapter(1, "Power Sharing", "POLITICAL SCIENCE"),
                DefaultChapter(2, "Federalism", "POLITICAL SCIENCE"),
                DefaultChapter(3, "Gender, Religion and Caste", "POLITICAL SCIENCE"),
                DefaultChapter(4, "Political Parties", "POLITICAL SCIENCE"),
                DefaultChapter(5, "Outcomes of Democracy", "POLITICAL SCIENCE"),
                // ECONOMICS
                DefaultChapter(1, "Development", "ECONOMICS"),
                DefaultChapter(2, "Sectors of the Indian Economy", "ECONOMICS"),
                DefaultChapter(3, "Money and Credit", "ECONOMICS"),
                DefaultChapter(4, "Globalisation and the Indian Economy", "ECONOMICS"),
                DefaultChapter(5, "Consumer Rights", "ECONOMICS")
            )
        ),
        DefaultSubject(
            id = "ENGLISH",
            name = "English – Language and Literature",
            iconName = "menu_book",
            displayOrder = 4,
            defaultChapters = listOf(
                // FIRST FLIGHT – PROSE
                DefaultChapter(1, "A Letter to God", "FIRST FLIGHT – PROSE"),
                DefaultChapter(2, "Nelson Mandela: Long Walk to Freedom", "FIRST FLIGHT – PROSE"),
                DefaultChapter(3, "Two Stories About Flying", "FIRST FLIGHT – PROSE"),
                DefaultChapter(4, "From the Diary of Anne Frank", "FIRST FLIGHT – PROSE"),
                DefaultChapter(5, "Glimpses of India", "FIRST FLIGHT – PROSE"),
                DefaultChapter(6, "Mijbil the Otter", "FIRST FLIGHT – PROSE"),
                DefaultChapter(7, "Madam Rides the Bus", "FIRST FLIGHT – PROSE"),
                DefaultChapter(8, "The Sermon at Benares", "FIRST FLIGHT – PROSE"),
                DefaultChapter(9, "The Proposal", "FIRST FLIGHT – PROSE"),
                // FIRST FLIGHT – POEMS
                DefaultChapter(1, "Dust of Snow", "FIRST FLIGHT – POEMS"),
                DefaultChapter(2, "Fire and Ice", "FIRST FLIGHT – POEMS"),
                DefaultChapter(3, "A Tiger in the Zoo", "FIRST FLIGHT – POEMS"),
                DefaultChapter(4, "How to Tell Wild Animals", "FIRST FLIGHT – POEMS"),
                DefaultChapter(5, "The Ball Poem", "FIRST FLIGHT – POEMS"),
                DefaultChapter(6, "Amanda!", "FIRST FLIGHT – POEMS"),
                DefaultChapter(7, "The Trees", "FIRST FLIGHT – POEMS"),
                DefaultChapter(8, "Fog", "FIRST FLIGHT – POEMS"),
                DefaultChapter(9, "The Tale of Custard the Dragon", "FIRST FLIGHT – POEMS"),
                DefaultChapter(10, "For Anne Gregory", "FIRST FLIGHT – POEMS"),
                // FOOTPRINTS WITHOUT FEET
                DefaultChapter(1, "A Triumph of Surgery", "FOOTPRINTS WITHOUT FEET"),
                DefaultChapter(2, "The Thief's Story", "FOOTPRINTS WITHOUT FEET"),
                DefaultChapter(3, "The Midnight Visitor", "FOOTPRINTS WITHOUT FEET"),
                DefaultChapter(4, "A Question of Trust", "FOOTPRINTS WITHOUT FEET"),
                DefaultChapter(5, "Footprints Without Feet", "FOOTPRINTS WITHOUT FEET"),
                DefaultChapter(6, "The Making of a Scientist", "FOOTPRINTS WITHOUT FEET"),
                DefaultChapter(7, "The Necklace", "FOOTPRINTS WITHOUT FEET"),
                DefaultChapter(8, "Bholi", "FOOTPRINTS WITHOUT FEET"),
                DefaultChapter(9, "The Book That Saved the Earth", "FOOTPRINTS WITHOUT FEET"),
                // WRITING AND GRAMMAR
                DefaultChapter(1, "Reading Comprehension", "WRITING AND GRAMMAR"),
                DefaultChapter(2, "Tenses", "WRITING AND GRAMMAR"),
                DefaultChapter(3, "Modals", "WRITING AND GRAMMAR"),
                DefaultChapter(4, "Subject-Verb Concord", "WRITING AND GRAMMAR"),
                DefaultChapter(5, "Reported Speech", "WRITING AND GRAMMAR"),
                DefaultChapter(6, "Determiners", "WRITING AND GRAMMAR"),
                DefaultChapter(7, "Formal Letter", "WRITING AND GRAMMAR"),
                DefaultChapter(8, "Analytical Paragraph", "WRITING AND GRAMMAR")
            )
        ),
        DefaultSubject(
            id = "HINDI",
            name = "Hindi – Course A",
            iconName = "translate",
            displayOrder = 5,
            defaultChapters = listOf(
                // क्षितिज भाग–2 (गद्य खंड)
                DefaultChapter(1, "नेताजी का चश्मा", "क्षितिज भाग–2 (गद्य खंड)"),
                DefaultChapter(2, "बालगोबिन भगत", "क्षितिज भाग–2 (गद्य खंड)"),
                DefaultChapter(3, "लखनवी अंदाज़", "क्षितिज भाग–2 (गद्य खंड)"),
                DefaultChapter(4, "मानवीय करुणा की दिव्य चमक", "क्षितिज भाग–2 (गद्य खंड)"),
                DefaultChapter(5, "एक कहानी यह भी", "क्षितिज भाग–2 (गद्य खंड)"),
                DefaultChapter(6, "स्त्री शिक्षा के विरोधी कुतर्कों का खंडन", "क्षितिज भाग–2 (गद्य खंड)"),
                DefaultChapter(7, "नौबतखाने में इबादत", "क्षितिज भाग–2 (गद्य खंड)"),
                DefaultChapter(8, "संस्कृति", "क्षितिज भाग–2 (गद्य खंड)"),
                // क्षितिज भाग–2 (काव्य खंड)
                DefaultChapter(1, "सूरदास के पद", "क्षितिज भाग–2 (काव्य खंड)"),
                DefaultChapter(2, "राम-लक्ष्मण-परशुराम संवाद", "क्षितिज भाग–2 (काव्य खंड)"),
                DefaultChapter(3, "आत्मकथ्य", "क्षितिज भाग–2 (काव्य खंड)"),
                DefaultChapter(4, "उत्साह और अट नहीं रही है", "क्षितिज भाग–2 (काव्य खंड)"),
                DefaultChapter(5, "यह दंतुरित मुस्कान और फसल", "क्षितिज भाग–2 (काव्य खंड)"),
                DefaultChapter(6, "छाया मत छूना", "क्षितिज भाग–2 (काव्य खंड)"),
                DefaultChapter(7, "कन्यादान", "क्षितिज भाग–2 (काव्य खंड)"),
                DefaultChapter(8, "संगतकार", "क्षितिज भाग–2 (काव्य खंड)"),
                // कृतिका भाग–2
                DefaultChapter(1, "माता का अँचल", "कृतिका भाग–2"),
                DefaultChapter(2, "जॉर्ज पंचम की नाक", "कृतिका भाग–2"),
                DefaultChapter(3, "साना-साना हाथ जोड़ि", "कृतिका भाग–2"),
                DefaultChapter(4, "एही ठैयाँ झुलनी हेरानी हो रामा!", "कृतिका भाग–2"),
                DefaultChapter(5, "मैं क्यों लिखता हूँ?", "कृतिका भाग–2"),
                // व्याकरण एवं लेखन
                DefaultChapter(1, "रचना के आधार पर वाक्य भेद", "व्याकरण एवं लेखन"),
                DefaultChapter(2, "वाच्य", "व्याकरण एवं लेखन"),
                DefaultChapter(3, "पद परिचय", "व्याकरण एवं लेखन"),
                DefaultChapter(4, "अलंकार", "व्याकरण एवं लेखन"),
                DefaultChapter(5, "अनुच्छेद लेखन", "व्याकरण एवं लेखन"),
                DefaultChapter(6, "पत्र लेखन", "व्याकरण एवं लेखन"),
                DefaultChapter(7, "स्ववृत्त लेखन", "व्याकरण एवं लेखन"),
                DefaultChapter(8, "विज्ञापन लेखन", "व्याकरण एवं लेखन")
            )
        ),
        DefaultSubject(
            id = "SANSKRIT",
            name = "Sanskrit – Communicative",
            iconName = "translate",
            displayOrder = 5,
            defaultChapters = listOf(
                // शेमुषी भाग–2
                DefaultChapter(1, "शुचिपर्यावरणम्", "शेमुषी भाग–2"),
                DefaultChapter(2, "बुद्धिर्बलवती सदा", "शेमुषी भाग–2"),
                DefaultChapter(3, "व्यायामः सर्वदा पथ्यः", "शेमुषी भाग–2"),
                DefaultChapter(4, "शिशुलालनम्", "शेमुषी भाग–2"),
                DefaultChapter(5, "जननी तुल्यवत्सला", "शेमुषी भाग–2"),
                DefaultChapter(6, "सुभाषितानि", "शेमुषी भाग–2"),
                DefaultChapter(7, "सौहार्दं प्रकृतेः शोभा", "शेमुषी भाग–2"),
                DefaultChapter(8, "विचित्रः साक्षी", "शेमुषी भाग–2"),
                DefaultChapter(9, "सूक्तयः", "शेमुषी भाग–2"),
                DefaultChapter(10, "भूकम्पविभीषिका", "शेमुषी भाग–2"),
                DefaultChapter(11, "प्राणेभ्योऽपि प्रियः सुहृद्", "शेमुषी भाग–2"),
                DefaultChapter(12, "अन्योक्तयः", "शेमुषी भाग–2"),
                // व्याकरण
                DefaultChapter(1, "सन्धि", "व्याकरण"),
                DefaultChapter(2, "समास", "व्याकरण"),
                DefaultChapter(3, "प्रत्यय", "व्याकरण"),
                DefaultChapter(4, "उपसर्ग", "व्याकरण"),
                DefaultChapter(5, "समयलेखनम्", "व्याकरण"),
                DefaultChapter(6, "अशुद्धि-संशोधनम्", "व्याकरण"),
                DefaultChapter(7, "वाच्य परिवर्तनम्", "व्याकरण"),
                DefaultChapter(8, "अव्यय", "व्याकरण"),
                DefaultChapter(9, "शब्दरूप", "व्याकरण"),
                DefaultChapter(10, "धातुरूप", "व्याकरण")
            )
        ),
        DefaultSubject(
            id = "AI",
            name = "Artificial Intelligence (417)",
            iconName = "psychology",
            displayOrder = 6,
            defaultChapters = listOf(
                // PART A – EMPLOYABILITY SKILLS
                DefaultChapter(1, "Communication Skills-II", "PART A – EMPLOYABILITY SKILLS"),
                DefaultChapter(2, "Self-Management Skills-II", "PART A – EMPLOYABILITY SKILLS"),
                DefaultChapter(3, "Information and Communication Technology Skills-II", "PART A – EMPLOYABILITY SKILLS"),
                DefaultChapter(4, "Entrepreneurial Skills-II", "PART A – EMPLOYABILITY SKILLS"),
                DefaultChapter(5, "Green Skills-II", "PART A – EMPLOYABILITY SKILLS"),
                // PART B – SUBJECT-SPECIFIC SKILLS
                DefaultChapter(1, "Revisiting AI Project Cycle and Ethical Frameworks for AI", "PART B – SUBJECT-SPECIFIC SKILLS"),
                DefaultChapter(2, "Advanced Concepts of Modelling in AI", "PART B – SUBJECT-SPECIFIC SKILLS"),
                DefaultChapter(3, "Evaluating Models", "PART B – SUBJECT-SPECIFIC SKILLS"),
                DefaultChapter(4, "Statistical Data", "PART B – SUBJECT-SPECIFIC SKILLS"),
                DefaultChapter(5, "Computer Vision", "PART B – SUBJECT-SPECIFIC SKILLS"),
                DefaultChapter(6, "Natural Language Processing", "PART B – SUBJECT-SPECIFIC SKILLS"),
                DefaultChapter(7, "Advanced Python", "PART B – SUBJECT-SPECIFIC SKILLS")
            )
        )
    )
}
