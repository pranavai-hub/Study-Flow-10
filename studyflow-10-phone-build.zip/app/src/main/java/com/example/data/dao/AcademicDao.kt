package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.example.data.model.ChapterEntity
import com.example.data.model.ChapterTaskEntity
import com.example.data.model.QuestionPaperEntity
import com.example.data.model.SubjectEntity
import kotlinx.coroutines.flow.Flow

data class ChapterWithTasks(
    val chapter: ChapterEntity,
    val tasks: List<ChapterTaskEntity>
) {
    val totalTasks: Int get() = tasks.size
    val completedTasks: Int get() = tasks.count { it.isCompleted }
    val progressPercentage: Double
        get() = if (totalTasks > 0) (completedTasks.toDouble() / totalTasks) * 100.0 else 0.0
}

data class SubjectProgress(
    val subjectId: String,
    val subjectName: String,
    val totalChapters: Int,
    val totalTasks: Int,
    val completedTasks: Int,
    val progressPercentage: Double
)

@Dao
interface SubjectDao {
    @Query("SELECT * FROM subjects ORDER BY displayOrder ASC")
    fun getAllSubjects(): Flow<List<SubjectEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubjects(subjects: List<SubjectEntity>)

    @Query("SELECT * FROM subjects WHERE id = :id")
    suspend fun getSubjectById(id: String): SubjectEntity?

    @Query("SELECT COUNT(*) FROM subjects")
    suspend fun getSubjectCount(): Int

    @Query("SELECT * FROM subjects")
    suspend fun getAllList(): List<SubjectEntity>

    @Query("DELETE FROM subjects")
    suspend fun clearAll()
}

@Dao
interface ChapterDao {
    @Query("SELECT * FROM chapters WHERE subjectId = :subjectId ORDER BY id ASC")
    fun getChaptersBySubject(subjectId: String): Flow<List<ChapterEntity>>

    @Query("SELECT * FROM chapters ORDER BY subjectId ASC, id ASC")
    fun getAllChapters(): Flow<List<ChapterEntity>>

    @Query("SELECT COUNT(*) FROM chapters WHERE subjectId = :subjectId")
    suspend fun getChapterCountForSubject(subjectId: String): Int

    @Query("SELECT * FROM chapters WHERE id = :chapterId")
    suspend fun getChapterById(chapterId: Long): ChapterEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChapter(chapter: ChapterEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChapters(chapters: List<ChapterEntity>): List<Long>

    @Update
    suspend fun updateChapter(chapter: ChapterEntity)

    @Delete
    suspend fun deleteChapter(chapter: ChapterEntity)

    @Query("DELETE FROM chapters WHERE id = :chapterId")
    suspend fun deleteChapterById(chapterId: Long)

    // Chapter Tasks
    @Query("SELECT * FROM chapter_tasks WHERE chapterId = :chapterId ORDER BY id ASC")
    fun getTasksForChapter(chapterId: Long): Flow<List<ChapterTaskEntity>>

    @Query("SELECT * FROM chapter_tasks ORDER BY chapterId ASC")
    fun getAllChapterTasks(): Flow<List<ChapterTaskEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: ChapterTaskEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTasks(tasks: List<ChapterTaskEntity>)

    @Update
    suspend fun updateTask(task: ChapterTaskEntity)

    @Query("UPDATE chapter_tasks SET isCompleted = :isCompleted, completedAt = :completedAt WHERE id = :taskId")
    suspend fun setTaskCompleted(taskId: Long, isCompleted: Boolean, completedAt: Long?)

    @Query("UPDATE chapter_tasks SET isCompleted = 0, completedAt = NULL WHERE chapterId = :chapterId")
    suspend fun resetChapterTasks(chapterId: Long)

    @Query("DELETE FROM chapter_tasks WHERE chapterId = :chapterId")
    suspend fun deleteTasksForChapter(chapterId: Long)

    @Query("SELECT COUNT(*) FROM chapter_tasks")
    fun getTotalTasksCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM chapter_tasks WHERE isCompleted = 1")
    fun getCompletedTasksCount(): Flow<Int>

    @Query("SELECT * FROM chapters")
    suspend fun getAllChaptersList(): List<ChapterEntity>

    @Query("SELECT * FROM chapter_tasks")
    suspend fun getAllTasksList(): List<ChapterTaskEntity>

    @Query("DELETE FROM chapters")
    suspend fun clearAllChapters()

    @Query("DELETE FROM chapter_tasks")
    suspend fun clearAllTasks()
}

@Dao
interface QuestionPaperDao {
    @Query("SELECT * FROM question_papers WHERE subjectId = :subjectId ORDER BY attemptDate DESC, id DESC")
    fun getPapersBySubject(subjectId: String): Flow<List<QuestionPaperEntity>>

    @Query("SELECT * FROM question_papers ORDER BY attemptDate DESC, id DESC")
    fun getAllPapers(): Flow<List<QuestionPaperEntity>>

    @Query("SELECT * FROM question_papers WHERE status = 'Completed' AND obtainedMarks IS NOT NULL ORDER BY attemptDate DESC")
    fun getCompletedPapers(): Flow<List<QuestionPaperEntity>>

    @Query("SELECT * FROM question_papers WHERE id = :id")
    suspend fun getPaperById(id: Long): QuestionPaperEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPaper(paper: QuestionPaperEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(papers: List<QuestionPaperEntity>)

    @Update
    suspend fun updatePaper(paper: QuestionPaperEntity)

    @Delete
    suspend fun deletePaper(paper: QuestionPaperEntity)

    @Query("DELETE FROM question_papers WHERE id = :id")
    suspend fun deletePaperById(id: Long)

    @Query("SELECT COUNT(*) FROM question_papers")
    fun getTotalPapersCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM question_papers WHERE status = 'Completed'")
    fun getCompletedPapersCount(): Flow<Int>

    @Query("SELECT * FROM question_papers")
    suspend fun getAllList(): List<QuestionPaperEntity>

    @Query("DELETE FROM question_papers")
    suspend fun clearAll()
}
