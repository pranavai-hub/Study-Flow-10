package com.example.data.repository

import com.example.data.model.ChapterEntity
import com.example.data.model.ChapterTaskEntity
import com.example.data.model.HomeworkEntity
import com.example.data.model.QuestionPaperEntity
import com.example.data.model.SubjectEntity
import org.json.JSONArray
import org.json.JSONObject

data class StudyFlowBackup(
    val exportTimestamp: Long,
    val appVersion: String,
    val studentName: String,
    val homeworkList: List<HomeworkEntity>,
    val subjects: List<SubjectEntity>,
    val chapters: List<ChapterEntity>,
    val tasks: List<ChapterTaskEntity>,
    val questionPapers: List<QuestionPaperEntity>
)

object BackupManager {

    fun exportToJson(backup: StudyFlowBackup): String {
        val root = JSONObject()
        root.put("app", "StudyFlow 10")
        root.put("version", backup.appVersion)
        root.put("exportTimestamp", backup.exportTimestamp)
        root.put("studentName", backup.studentName)

        val hwArray = JSONArray()
        for (hw in backup.homeworkList) {
            val obj = JSONObject()
            obj.put("id", hw.id)
            obj.put("title", hw.title)
            obj.put("subject", hw.subject)
            obj.put("notes", hw.notes)
            if (hw.dueDate != null) obj.put("dueDate", hw.dueDate)
            obj.put("createdAt", hw.createdAt)
            obj.put("isCompleted", hw.isCompleted)
            hwArray.put(obj)
        }
        root.put("homework", hwArray)

        val subArray = JSONArray()
        for (sub in backup.subjects) {
            val obj = JSONObject()
            obj.put("id", sub.id)
            obj.put("name", sub.name)
            obj.put("iconName", sub.iconName)
            obj.put("displayOrder", sub.displayOrder)
            subArray.put(obj)
        }
        root.put("subjects", subArray)

        val chArray = JSONArray()
        for (ch in backup.chapters) {
            val obj = JSONObject()
            obj.put("id", ch.id)
            obj.put("subjectId", ch.subjectId)
            if (ch.chapterNumber != null) obj.put("chapterNumber", ch.chapterNumber)
            obj.put("name", ch.name)
            obj.put("notes", ch.notes)
            obj.put("createdAt", ch.createdAt)
            chArray.put(obj)
        }
        root.put("chapters", chArray)

        val taskArray = JSONArray()
        for (t in backup.tasks) {
            val obj = JSONObject()
            obj.put("id", t.id)
            obj.put("chapterId", t.chapterId)
            obj.put("taskType", t.taskType)
            obj.put("isCompleted", t.isCompleted)
            if (t.completedAt != null) obj.put("completedAt", t.completedAt)
            taskArray.put(obj)
        }
        root.put("tasks", taskArray)

        val qpArray = JSONArray()
        for (qp in backup.questionPapers) {
            val obj = JSONObject()
            obj.put("id", qp.id)
            obj.put("subjectId", qp.subjectId)
            obj.put("paperName", qp.paperName)
            obj.put("maxMarks", qp.maxMarks)
            if (qp.obtainedMarks != null) obj.put("obtainedMarks", qp.obtainedMarks)
            obj.put("attemptDate", qp.attemptDate)
            if (qp.durationMinutes != null) obj.put("durationMinutes", qp.durationMinutes)
            obj.put("notes", qp.notes)
            obj.put("status", qp.status)
            qpArray.put(obj)
        }
        root.put("questionPapers", qpArray)

        return root.toString(2)
    }

    fun parseBackupJson(jsonString: String): Result<StudyFlowBackup> {
        return try {
            val root = JSONObject(jsonString)
            if (!root.has("app") || root.getString("app") != "StudyFlow 10") {
                return Result.failure(IllegalArgumentException("Invalid backup file: Not a StudyFlow 10 backup"))
            }

            val timestamp = root.optLong("exportTimestamp", System.currentTimeMillis())
            val version = root.optString("version", "1.0")
            val studentName = root.optString("studentName", "")

            val hwList = mutableListOf<HomeworkEntity>()
            val hwArray = root.optJSONArray("homework") ?: JSONArray()
            for (i in 0 until hwArray.length()) {
                val obj = hwArray.getJSONObject(i)
                hwList.add(
                    HomeworkEntity(
                        id = obj.optLong("id", 0),
                        title = obj.getString("title"),
                        subject = obj.optString("subject", ""),
                        notes = obj.optString("notes", ""),
                        dueDate = if (obj.has("dueDate")) obj.getLong("dueDate") else null,
                        createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                        isCompleted = obj.optBoolean("isCompleted", false)
                    )
                )
            }

            val subList = mutableListOf<SubjectEntity>()
            val subArray = root.optJSONArray("subjects") ?: JSONArray()
            for (i in 0 until subArray.length()) {
                val obj = subArray.getJSONObject(i)
                subList.add(
                    SubjectEntity(
                        id = obj.getString("id"),
                        name = obj.getString("name"),
                        iconName = obj.optString("iconName", "menu_book"),
                        displayOrder = obj.optInt("displayOrder", i)
                    )
                )
            }

            val chList = mutableListOf<ChapterEntity>()
            val chArray = root.optJSONArray("chapters") ?: JSONArray()
            for (i in 0 until chArray.length()) {
                val obj = chArray.getJSONObject(i)
                chList.add(
                    ChapterEntity(
                        id = obj.optLong("id", 0),
                        subjectId = obj.getString("subjectId"),
                        chapterNumber = if (obj.has("chapterNumber")) obj.getInt("chapterNumber") else null,
                        name = obj.getString("name"),
                        notes = obj.optString("notes", ""),
                        createdAt = obj.optLong("createdAt", System.currentTimeMillis())
                    )
                )
            }

            val taskList = mutableListOf<ChapterTaskEntity>()
            val taskArray = root.optJSONArray("tasks") ?: JSONArray()
            for (i in 0 until taskArray.length()) {
                val obj = taskArray.getJSONObject(i)
                taskList.add(
                    ChapterTaskEntity(
                        id = obj.optLong("id", 0),
                        chapterId = obj.getLong("chapterId"),
                        taskType = obj.getString("taskType"),
                        isCompleted = obj.optBoolean("isCompleted", false),
                        completedAt = if (obj.has("completedAt")) obj.getLong("completedAt") else null
                    )
                )
            }

            val qpList = mutableListOf<QuestionPaperEntity>()
            val qpArray = root.optJSONArray("questionPapers") ?: JSONArray()
            for (i in 0 until qpArray.length()) {
                val obj = qpArray.getJSONObject(i)
                qpList.add(
                    QuestionPaperEntity(
                        id = obj.optLong("id", 0),
                        subjectId = obj.getString("subjectId"),
                        paperName = obj.getString("paperName"),
                        maxMarks = obj.getDouble("maxMarks"),
                        obtainedMarks = if (obj.has("obtainedMarks")) obj.getDouble("obtainedMarks") else null,
                        attemptDate = obj.optLong("attemptDate", System.currentTimeMillis()),
                        durationMinutes = if (obj.has("durationMinutes")) obj.getInt("durationMinutes") else null,
                        notes = obj.optString("notes", ""),
                        status = obj.optString("status", QuestionPaperEntity.STATUS_NOT_STARTED)
                    )
                )
            }

            Result.success(
                StudyFlowBackup(
                    exportTimestamp = timestamp,
                    appVersion = version,
                    studentName = studentName,
                    homeworkList = hwList,
                    subjects = subList,
                    chapters = chList,
                    tasks = taskList,
                    questionPapers = qpList
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
