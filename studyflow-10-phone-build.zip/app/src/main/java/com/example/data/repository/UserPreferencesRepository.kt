package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class UserPreferences(
    val studentName: String = "",
    val isOnboarded: Boolean = false,
    val themeMode: String = THEME_SYSTEM, // "SYSTEM", "LIGHT", "DARK"
    val secondLanguage: String = LANGUAGE_HINDI, // "HINDI" or "SANSKRIT"
    val isReminderEnabled: Boolean = true,
    val reminderHour: Int = 16, // 4:30 PM default (as chosen by user)
    val reminderMinute: Int = 30
) {
    companion object {
        const val THEME_SYSTEM = "System Default"
        const val THEME_LIGHT = "Light"
        const val THEME_DARK = "Dark"

        const val LANGUAGE_HINDI = "HINDI"
        const val LANGUAGE_SANSKRIT = "SANSKRIT"
    }
}

class UserPreferencesRepository(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences(
        "studyflow10_prefs",
        Context.MODE_PRIVATE
    )

    private val _preferences = MutableStateFlow(loadPreferences())
    val preferences: StateFlow<UserPreferences> = _preferences.asStateFlow()

    private fun loadPreferences(): UserPreferences {
        return UserPreferences(
            studentName = prefs.getString("student_name", "") ?: "",
            isOnboarded = prefs.getBoolean("is_onboarded", false),
            themeMode = prefs.getString("theme_mode", UserPreferences.THEME_SYSTEM) ?: UserPreferences.THEME_SYSTEM,
            secondLanguage = prefs.getString("second_language", UserPreferences.LANGUAGE_HINDI) ?: UserPreferences.LANGUAGE_HINDI,
            isReminderEnabled = prefs.getBoolean("is_reminder_enabled", true),
            reminderHour = prefs.getInt("reminder_hour", 16),
            reminderMinute = prefs.getInt("reminder_minute", 30)
        )
    }

    fun setStudentName(name: String) {
        val trimmed = name.trim()
        prefs.edit().putString("student_name", trimmed).apply()
        _preferences.value = _preferences.value.copy(studentName = trimmed)
    }

    fun completeOnboarding(name: String, secondLanguage: String = _preferences.value.secondLanguage) {
        val trimmed = name.trim()
        prefs.edit()
            .putString("student_name", trimmed)
            .putString("second_language", secondLanguage)
            .putBoolean("is_onboarded", true)
            .apply()
        _preferences.value = _preferences.value.copy(
            studentName = trimmed,
            secondLanguage = secondLanguage,
            isOnboarded = true
        )
    }

    fun setSecondLanguage(language: String) {
        prefs.edit().putString("second_language", language).apply()
        _preferences.value = _preferences.value.copy(secondLanguage = language)
    }

    fun setThemeMode(themeMode: String) {
        prefs.edit().putString("theme_mode", themeMode).apply()
        _preferences.value = _preferences.value.copy(themeMode = themeMode)
    }

    fun setReminderEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("is_reminder_enabled", enabled).apply()
        _preferences.value = _preferences.value.copy(isReminderEnabled = enabled)
    }

    fun setReminderTime(hour: Int, minute: Int) {
        prefs.edit()
            .putInt("reminder_hour", hour)
            .putInt("reminder_minute", minute)
            .apply()
        _preferences.value = _preferences.value.copy(reminderHour = hour, reminderMinute = minute)
    }

    fun resetPreferences() {
        prefs.edit().clear().apply()
        _preferences.value = UserPreferences(
            studentName = "",
            isOnboarded = false,
            themeMode = UserPreferences.THEME_SYSTEM,
            secondLanguage = UserPreferences.LANGUAGE_HINDI,
            isReminderEnabled = true,
            reminderHour = 16,
            reminderMinute = 30
        )
    }
}
