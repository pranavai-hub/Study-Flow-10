package com.example.data.repository

import com.example.data.dao.ChapterDao
import com.example.data.dao.HomeworkDao
import com.example.data.dao.QuestionPaperDao
import com.example.data.dao.SubjectDao
import com.example.data.db.StudyFlowDatabase
import com.example.data.model.CbseSyllabusData
import com.example.data.model.ChapterEntity
import com.example.data.model.ChapterTaskEntity
import com.example.data.model.HomeworkEntity
import com.example.data.model.QuestionPaperEntity
import com.example.data.model.SubjectEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

class StudyFlowRepository(
    private val database: StudyFlowDatabase
) {
    private val homeworkDao: HomeworkDao = database.homeworkDao()
    private val subjectDao: SubjectDao = database.subjectDao()
    private val chapterDao: ChapterDao = database.chapterDao()
    private val questionPaperDao: QuestionPaperDao = database.questionPaperDao()

    // Homework
    val allHomework: Flow<List<HomeworkEntity>> = homeworkDao.getAllHomework()
    val pendingHomework: Flow<List<HomeworkEntity>> = homeworkDao.getPendingHomework()
    val completedHomework: Flow<List<HomeworkEntity>> = homeworkDao.getCompletedHomework()
    val totalHomeworkCount: Flow<Int> = homeworkDao.getTotalCount()
    val pendingHomeworkCount: Flow<Int> = homeworkDao.getPendingCount()
    val completedHomeworkCount: Flow<Int> = homeworkDao.getCompletedCount()

    suspend fun addHomework(title: String, subject: String, notes: String, dueDate: Long?): Long {
        return withContext(Dispatchers.IO) {
            val entity = HomeworkEntity(
                title = title.trim(),
                subject = subject.trim(),
                notes = notes.trim(),
                dueDate = dueDate,
                createdAt = System.currentTimeMillis(),
                isCompleted = false
            )
            homeworkDao.insertHomework(entity)
        }
    }

    suspend fun toggleHomework(homework: HomeworkEntity) {
        withContext(Dispatchers.IO) {
            homeworkDao.updateHomework(homework.copy(isCompleted = !homework.isCompleted))
        }
    }

    suspend fun updateHomework(homework: HomeworkEntity) {
        withContext(Dispatchers.IO) {
            homeworkDao.updateHomework(homework)
        }
    }

    suspend fun deleteHomework(id: Long) {
        withContext(Dispatchers.IO) {
            homeworkDao.deleteHomeworkById(id)
        }
    }

    // Subjects
    val allSubjects: Flow<List<SubjectEntity>> = subjectDao.getAllSubjects()

    // Chapters
    val allChapters: Flow<List<ChapterEntity>> = chapterDao.getAllChapters()
    val allChapterTasks: Flow<List<ChapterTaskEntity>> = chapterDao.getAllChapterTasks()
    val totalTasksCount: Flow<Int> = chapterDao.getTotalTasksCount()
    val completedTasksCount: Flow<Int> = chapterDao.getCompletedTasksCount()

    fun getChaptersForSubject(subjectId: String): Flow<List<ChapterEntity>> {
        return chapterDao.getChaptersBySubject(subjectId)
    }

    fun getTasksForChapter(chapterId: Long): Flow<List<ChapterTaskEntity>> {
        return chapterDao.getTasksForChapter(chapterId)
    }

    suspend fun addChapter(subjectId: String, name: String, chapterNumber: Int?, notes: String): Long {
        return withContext(Dispatchers.IO) {
            val chapter = ChapterEntity(
                subjectId = subjectId,
                chapterNumber = chapterNumber,
                name = name.trim(),
                notes = notes.trim()
            )
            val chapterId = chapterDao.insertChapter(chapter)
            // Automatically initialize the 7 CBSE task categories
            val tasks = ChapterTaskEntity.ALL_TASK_TYPES.map { taskType ->
                ChapterTaskEntity(
                    chapterId = chapterId,
                    taskType = taskType,
                    isCompleted = false
                )
            }
            chapterDao.insertTasks(tasks)
            chapterId
        }
    }

    suspend fun updateChapter(chapter: ChapterEntity) {
        withContext(Dispatchers.IO) {
            chapterDao.updateChapter(chapter)
        }
    }

    suspend fun deleteChapter(chapterId: Long) {
        withContext(Dispatchers.IO) {
            chapterDao.deleteTasksForChapter(chapterId)
            chapterDao.deleteChapterById(chapterId)
        }
    }

    suspend fun toggleChapterTask(task: ChapterTaskEntity) {
        withContext(Dispatchers.IO) {
            val newCompleted = !task.isCompleted
            val completedTime = if (newCompleted) System.currentTimeMillis() else null
            chapterDao.setTaskCompleted(task.id, newCompleted, completedTime)
        }
    }

    suspend fun resetChapterChecklist(chapterId: Long) {
        withContext(Dispatchers.IO) {
            chapterDao.resetChapterTasks(chapterId)
        }
    }

    // Question Papers
    val allQuestionPapers: Flow<List<QuestionPaperEntity>> = questionPaperDao.getAllPapers()
    val completedQuestionPapers: Flow<List<QuestionPaperEntity>> = questionPaperDao.getCompletedPapers()
    val totalPapersCount: Flow<Int> = questionPaperDao.getTotalPapersCount()
    val completedPapersCount: Flow<Int> = questionPaperDao.getCompletedPapersCount()

    fun getQuestionPapersForSubject(subjectId: String): Flow<List<QuestionPaperEntity>> {
        return questionPaperDao.getPapersBySubject(subjectId)
    }

    suspend fun addQuestionPaper(
        subjectId: String,
        paperName: String,
        maxMarks: Double,
        obtainedMarks: Double?,
        attemptDate: Long,
        durationMinutes: Int?,
        notes: String,
        status: String
    ): Long {
        return withContext(Dispatchers.IO) {
            val entity = QuestionPaperEntity(
                subjectId = subjectId,
                paperName = paperName.trim(),
                maxMarks = maxMarks,
                obtainedMarks = obtainedMarks,
                attemptDate = attemptDate,
                durationMinutes = durationMinutes,
                notes = notes.trim(),
                status = status
            )
            questionPaperDao.insertPaper(entity)
        }
    }

    suspend fun updateQuestionPaper(paper: QuestionPaperEntity) {
        withContext(Dispatchers.IO) {
            questionPaperDao.updatePaper(paper)
        }
    }

    suspend fun deleteQuestionPaper(id: Long) {
        withContext(Dispatchers.IO) {
            questionPaperDao.deletePaperById(id)
        }
    }

    // Pre-population and 2026-27 syllabus sync check
    suspend fun checkAndSeedSyllabus() {
        withContext(Dispatchers.IO) {
            StudyFlowDatabase.populateInitialSyllabus(database)
        }
    }

    // Backup & Restore
    suspend fun createBackup(studentName: String, appVersion: String): StudyFlowBackup {
        return withContext(Dispatchers.IO) {
            StudyFlowBackup(
                exportTimestamp = System.currentTimeMillis(),
                appVersion = appVersion,
                studentName = studentName,
                homeworkList = homeworkDao.getAllList(),
                subjects = subjectDao.getAllList(),
                chapters = chapterDao.getAllChaptersList(),
                tasks = chapterDao.getAllTasksList(),
                questionPapers = questionPaperDao.getAllList()
            )
        }
    }

    suspend fun restoreBackup(backup: StudyFlowBackup, replaceExisting: Boolean) {
        withContext(Dispatchers.IO) {
            if (replaceExisting) {
                homeworkDao.clearAll()
                chapterDao.clearAllTasks()
                chapterDao.clearAllChapters()
                subjectDao.clearAll()
                questionPaperDao.clearAll()
            }

            if (backup.subjects.isNotEmpty()) {
                subjectDao.insertSubjects(backup.subjects)
            }
            if (backup.chapters.isNotEmpty()) {
                chapterDao.insertChapters(backup.chapters)
            }
            if (backup.tasks.isNotEmpty()) {
                chapterDao.insertTasks(backup.tasks)
            }
            if (backup.homeworkList.isNotEmpty()) {
                homeworkDao.insertAll(backup.homeworkList)
            }
            if (backup.questionPapers.isNotEmpty()) {
                questionPaperDao.insertAll(backup.questionPapers)
            }
        }
    }

    suspend fun resetAllData() {
        withContext(Dispatchers.IO) {
            homeworkDao.clearAll()
            chapterDao.clearAllTasks()
            chapterDao.clearAllChapters()
            questionPaperDao.clearAll()
            // Re-seed standard syllabus
            StudyFlowDatabase.populateInitialSyllabus(database)
        }
    }
}
