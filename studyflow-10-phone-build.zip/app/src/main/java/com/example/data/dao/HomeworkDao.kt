package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.HomeworkEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface HomeworkDao {
    @Query("SELECT * FROM homework ORDER BY isCompleted ASC, dueDate ASC, createdAt DESC")
    fun getAllHomework(): Flow<List<HomeworkEntity>>

    @Query("SELECT * FROM homework WHERE isCompleted = 0 ORDER BY dueDate ASC, createdAt DESC")
    fun getPendingHomework(): Flow<List<HomeworkEntity>>

    @Query("SELECT * FROM homework WHERE isCompleted = 1 ORDER BY createdAt DESC")
    fun getCompletedHomework(): Flow<List<HomeworkEntity>>

    @Query("SELECT * FROM homework WHERE id = :id")
    suspend fun getHomeworkById(id: Long): HomeworkEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHomework(homework: HomeworkEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(homeworkList: List<HomeworkEntity>)

    @Update
    suspend fun updateHomework(homework: HomeworkEntity)

    @Delete
    suspend fun deleteHomework(homework: HomeworkEntity)

    @Query("DELETE FROM homework WHERE id = :id")
    suspend fun deleteHomeworkById(id: Long)

    @Query("SELECT COUNT(*) FROM homework")
    fun getTotalCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM homework WHERE isCompleted = 0")
    fun getPendingCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM homework WHERE isCompleted = 1")
    fun getCompletedCount(): Flow<Int>

    @Query("DELETE FROM homework")
    suspend fun clearAll()

    @Query("SELECT * FROM homework")
    suspend fun getAllList(): List<HomeworkEntity>
}
