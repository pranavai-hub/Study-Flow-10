package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "subjects")
data class SubjectEntity(
    @PrimaryKey
    val id: String, // "MATH", "SCIENCE", "SST", "ENGLISH", "HINDI", "AI"
    val name: String,
    val iconName: String,
    val displayOrder: Int
)

@Entity(tableName = "chapters")
data class ChapterEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val subjectId: String,
    val chapterNumber: Int? = null,
    val name: String,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "chapter_tasks")
data class ChapterTaskEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val chapterId: Long,
    val taskType: String, // "NCERT Reading", "Lecture", "NCERT Questions", "PYQ", "CBT Questions", "Hard-Level Questions", "Sample Paper Practice"
    val isCompleted: Boolean = false,
    val completedAt: Long? = null
) {
    companion object {
        val ALL_TASK_TYPES = listOf(
            "NCERT Reading",
            "Lecture",
            "NCERT Questions",
            "PYQ",
            "CBT Questions",
            "Hard-Level Questions",
            "Sample Paper Practice"
        )
    }
}

@Entity(tableName = "question_papers")
data class QuestionPaperEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val subjectId: String,
    val paperName: String,
    val maxMarks: Double,
    val obtainedMarks: Double? = null,
    val attemptDate: Long = System.currentTimeMillis(),
    val durationMinutes: Int? = null,
    val notes: String = "",
    val status: String = STATUS_NOT_STARTED // "NOT_STARTED", "IN_PROGRESS", "COMPLETED"
) {
    companion object {
        const val STATUS_NOT_STARTED = "Not Started"
        const val STATUS_IN_PROGRESS = "In Progress"
        const val STATUS_COMPLETED = "Completed"
    }

    val percentage: Double?
        get() = if (obtainedMarks != null && maxMarks > 0) {
            (obtainedMarks / maxMarks) * 100.0
        } else null
}
