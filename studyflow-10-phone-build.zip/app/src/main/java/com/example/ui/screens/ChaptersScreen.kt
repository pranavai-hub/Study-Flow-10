package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.outlined.AutoStories
import androidx.compose.material.icons.outlined.Calculate
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material.icons.outlined.Public
import androidx.compose.material.icons.outlined.RestartAlt
import androidx.compose.material.icons.outlined.Science
import androidx.compose.material.icons.outlined.Translate
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ChapterEntity
import com.example.data.model.ChapterTaskEntity
import com.example.data.model.SubjectEntity
import com.example.ui.components.ConfirmationDialog
import com.example.ui.components.getSubjectColor
import com.example.ui.theme.AiColor
import com.example.ui.theme.EnglishColor
import com.example.ui.theme.HindiColor
import com.example.ui.theme.MathColor
import com.example.ui.theme.ScienceColor
import com.example.ui.theme.SstColor
import com.example.ui.theme.SuccessGreen
import com.example.ui.viewmodel.SubjectProgressItem

@Composable
fun ChaptersScreen(
    subjects: List<SubjectEntity>,
    chapters: List<ChapterEntity>,
    tasks: List<ChapterTaskEntity>,
    subjectProgressList: List<SubjectProgressItem>,
    onToggleTask: (ChapterTaskEntity) -> Unit,
    onResetChapterChecklist: (Long) -> Unit,
    onDeleteChapter: (Long) -> Unit,
    onAddChapterClick: (subjectId: String, subjectName: String) -> Unit
) {
    var selectedSubjectId by remember { mutableStateOf<String?>(null) }
    var chapterToReset by remember { mutableStateOf<ChapterEntity?>(null) }
    var chapterToDelete by remember { mutableStateOf<ChapterEntity?>(null) }

    // Android back handling: if in subject chapter list, return to subject selector
    BackHandler(enabled = selectedSubjectId != null) {
        selectedSubjectId = null
    }

    if (chapterToReset != null) {
        ConfirmationDialog(
            title = "Reset Chapter Progress",
            message = "Reset all 7 preparation checklist items for \"${chapterToReset!!.name}\"? This action cannot be undone.",
            confirmButtonText = "Reset Checklist",
            isDestructive = true,
            onConfirm = {
                onResetChapterChecklist(chapterToReset!!.id)
                chapterToReset = null
            },
            onDismiss = { chapterToReset = null }
        )
    }

    if (chapterToDelete != null) {
        ConfirmationDialog(
            title = "Delete Chapter",
            message = "Permanently remove \"${chapterToDelete!!.name}\" and its task history?",
            confirmButtonText = "Delete Chapter",
            isDestructive = true,
            onConfirm = {
                onDeleteChapter(chapterToDelete!!.id)
                chapterToDelete = null
            },
            onDismiss = { chapterToDelete = null }
        )
    }

    if (selectedSubjectId == null) {
        // Six Subject Cards View
        SubjectSelectionView(
            subjects = subjects,
            subjectProgressList = subjectProgressList,
            onSelectSubject = { selectedSubjectId = it }
        )
    } else {
        // Chapters for Selected Subject View
        val currentSubject = subjects.find { it.id == selectedSubjectId }
        val subjectName = currentSubject?.name ?: "Subject"
        val subjectChapters = chapters.filter { it.subjectId == selectedSubjectId }

        Scaffold(
            floatingActionButton = {
                FloatingActionButton(
                    onClick = { onAddChapterClick(selectedSubjectId!!, subjectName) },
                    containerColor = getSubjectColor(subjectName),
                    contentColor = Color.White,
                    modifier = Modifier.testTag("add_chapter_fab")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Add Chapter")
                }
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                // Header Bar with Back button
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 2.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { selectedSubjectId = null },
                            modifier = Modifier.testTag("back_to_subjects_btn")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back to Subjects"
                            )
                        }

                        Spacer(modifier = Modifier.width(4.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = subjectName,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            val progress = subjectProgressList.find { it.subjectId == selectedSubjectId }
                            Text(
                                text = "${subjectChapters.size} Chapters • ${String.format("%.0f", progress?.progressPercentage ?: 0.0)}% Completed",
                                style = MaterialTheme.typography.bodySmall,
                                color = getSubjectColor(subjectName)
                            )
                        }

                        Button(
                            onClick = { onAddChapterClick(selectedSubjectId!!, subjectName) },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Text("+ Add")
                        }
                    }
                }

                if (subjectChapters.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.AutoStories,
                                contentDescription = null,
                                tint = getSubjectColor(subjectName).copy(alpha = 0.5f),
                                modifier = Modifier.size(54.dp)
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "No chapters found for $subjectName",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Tap '+ Add' to create your first chapter for this syllabus.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(subjectChapters, key = { it.id }) { chapter ->
                            val chapterTasks = tasks.filter { it.chapterId == chapter.id }
                            ChapterItemCard(
                                chapter = chapter,
                                tasks = chapterTasks,
                                subjectName = subjectName,
                                onToggleTask = onToggleTask,
                                onResetChecklist = { chapterToReset = chapter },
                                onDeleteChapter = { chapterToDelete = chapter }
                            )
                        }
                        item {
                            Spacer(modifier = Modifier.height(64.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SubjectSelectionView(
    subjects: List<SubjectEntity>,
    subjectProgressList: List<SubjectProgressItem>,
    onSelectSubject: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "Class 10 CBSE Subjects",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "Select a subject to track the 7-step preparation workflow for every chapter.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(4.dp))
        }

        items(subjects, key = { it.id }) { subject ->
            val progressItem = subjectProgressList.find { it.subjectId == subject.id }
            SubjectCard(
                subject = subject,
                progressItem = progressItem,
                onClick = { onSelectSubject(subject.id) }
            )
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun SubjectCard(
    subject: SubjectEntity,
    progressItem: SubjectProgressItem?,
    onClick: () -> Unit
) {
    val subColor = getSubjectColor(subject.name)
    val progressPct = progressItem?.progressPercentage ?: 0.0
    val totalChaps = progressItem?.totalChapters ?: 0
    val completedTasks = progressItem?.completedTasks ?: 0
    val totalTasks = progressItem?.totalTasks ?: 0

    val iconVector: ImageVector = when (subject.id) {
        "MATH" -> Icons.Outlined.Calculate
        "SCIENCE" -> Icons.Outlined.Science
        "SST" -> Icons.Outlined.Public
        "ENGLISH" -> Icons.Outlined.MenuBook
        "HINDI" -> Icons.Outlined.Translate
        "AI" -> Icons.Outlined.Psychology
        else -> Icons.Outlined.AutoStories
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("subject_card_${subject.id}"),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .background(subColor.copy(alpha = 0.14f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = iconVector,
                        contentDescription = null,
                        tint = subColor,
                        modifier = Modifier.size(26.dp)
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = subject.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "$totalChaps Chapters • $completedTasks/$totalTasks Tasks Done",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "${String.format("%.0f", progressPct)}%",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = subColor
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            LinearProgressIndicator(
                progress = { (progressPct / 100.0).toFloat().coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = subColor,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )
        }
    }
}

@Composable
private fun ChapterItemCard(
    chapter: ChapterEntity,
    tasks: List<ChapterTaskEntity>,
    subjectName: String,
    onToggleTask: (ChapterTaskEntity) -> Unit,
    onResetChecklist: () -> Unit,
    onDeleteChapter: () -> Unit
) {
    var isExpanded by remember { mutableStateOf(false) }
    val completedCount = tasks.count { it.isCompleted }
    val totalCount = tasks.size
    val progressPct = if (totalCount > 0) (completedCount.toDouble() / totalCount) * 100.0 else 0.0
    val subColor = getSubjectColor(subjectName)

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { isExpanded = !isExpanded },
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Chapter Number Badge
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .background(subColor.copy(alpha = 0.12f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${chapter.chapterNumber ?: "#"}",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = subColor
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = chapter.name,
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "$completedCount of $totalCount steps completed (${String.format("%.0f", progressPct)}%)",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (completedCount == totalCount && totalCount > 0) SuccessGreen else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                IconButton(onClick = { isExpanded = !isExpanded }) {
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = if (isExpanded) "Collapse" else "Expand"
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            LinearProgressIndicator(
                progress = { (progressPct / 100.0).toFloat().coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = if (completedCount == totalCount && totalCount > 0) SuccessGreen else subColor,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )

            // Expanded 7 Task Checklist
            AnimatedVisibility(visible = isExpanded) {
                Column(modifier = Modifier.padding(top = 12.dp)) {
                    Text(
                        text = "CBSE Preparation Checklist (7 Steps):",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    tasks.forEach { task ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onToggleTask(task) }
                                .padding(vertical = 4.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = task.isCompleted,
                                onCheckedChange = { onToggleTask(task) }
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = task.taskType,
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (task.isCompleted) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = if (task.isCompleted) FontWeight.Medium else FontWeight.Normal
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onResetChecklist) {
                            Icon(
                                imageVector = Icons.Outlined.RestartAlt,
                                contentDescription = "Reset Checklist",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(onClick = onDeleteChapter) {
                            Icon(
                                imageVector = Icons.Outlined.Delete,
                                contentDescription = "Delete Chapter",
                                tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f)
                            )
                        }
                    }
                }
            }
        }
    }
}
