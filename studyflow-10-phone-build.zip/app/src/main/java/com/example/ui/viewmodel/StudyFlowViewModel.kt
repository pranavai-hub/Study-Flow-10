package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.StudyFlowDatabase
import com.example.data.model.ChapterEntity
import com.example.data.model.ChapterTaskEntity
import com.example.data.model.HomeworkEntity
import com.example.data.model.QuestionPaperEntity
import com.example.data.model.SubjectEntity
import com.example.data.repository.BackupManager
import com.example.data.repository.StudyFlowBackup
import com.example.data.repository.StudyFlowRepository
import com.example.data.repository.UserPreferences
import com.example.data.repository.UserPreferencesRepository
import com.example.notification.NotificationHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class SubjectProgressItem(
    val subjectId: String,
    val subjectName: String,
    val totalChapters: Int,
    val totalTasks: Int,
    val completedTasks: Int,
    val progressPercentage: Double
)

data class SubjectScoreStats(
    val subjectId: String,
    val subjectName: String,
    val completedPapersCount: Int,
    val averagePercentage: Double?,
    val highestPercentage: Double?,
    val latestPercentage: Double?,
    val trendDelta: Double? // difference from earliest to latest or previous
)

data class StudySuggestion(
    val title: String,
    val description: String,
    val priority: SuggestionPriority
)

enum class SuggestionPriority { HIGH, MEDIUM, LOW }

class StudyFlowViewModel(application: Application) : AndroidViewModel(application) {

    private val userPrefsRepo = UserPreferencesRepository(application)
    private val database = StudyFlowDatabase.getDatabase(application, viewModelScope)
    private val studyRepo = StudyFlowRepository(database)

    val userPreferences: StateFlow<UserPreferences> = userPrefsRepo.preferences

    val allHomework: StateFlow<List<HomeworkEntity>> = studyRepo.allHomework.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val pendingHomework: StateFlow<List<HomeworkEntity>> = studyRepo.pendingHomework.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val completedHomework: StateFlow<List<HomeworkEntity>> = studyRepo.completedHomework.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val subjects: StateFlow<List<SubjectEntity>> = studyRepo.allSubjects.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val chapters: StateFlow<List<ChapterEntity>> = studyRepo.allChapters.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val chapterTasks: StateFlow<List<ChapterTaskEntity>> = studyRepo.allChapterTasks.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val questionPapers: StateFlow<List<QuestionPaperEntity>> = studyRepo.allQuestionPapers.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val completedPapers: StateFlow<List<QuestionPaperEntity>> = studyRepo.completedQuestionPapers.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Subject Progress calculation
    val subjectProgressList: StateFlow<List<SubjectProgressItem>> = combine(
        subjects,
        chapters,
        chapterTasks
    ) { subs, chaps, tasks ->
        subs.map { subject ->
            val subjectChapters = chaps.filter { it.subjectId == subject.id }
            val chapterIds = subjectChapters.map { it.id }.toSet()
            val subjectTasks = tasks.filter { chapterIds.contains(it.chapterId) }
            val totalTasks = subjectTasks.size
            val completedTasks = subjectTasks.count { it.isCompleted }
            val pct = if (totalTasks > 0) (completedTasks.toDouble() / totalTasks) * 100.0 else 0.0

            SubjectProgressItem(
                subjectId = subject.id,
                subjectName = subject.name,
                totalChapters = subjectChapters.size,
                totalTasks = totalTasks,
                completedTasks = completedTasks,
                progressPercentage = pct
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Overall Chapter Completion %
    val overallChapterProgress: StateFlow<Double> = chapterTasks.combine(chapters) { tasks, _ ->
        val total = tasks.size
        val done = tasks.count { it.isCompleted }
        if (total > 0) (done.toDouble() / total) * 100.0 else 0.0
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // Subject Scores Analytics
    val subjectScoreStats: StateFlow<List<SubjectScoreStats>> = combine(
        subjects,
        completedPapers
    ) { subs, papers ->
        subs.map { subject ->
            val subPapers = papers.filter { it.subjectId == subject.id && it.percentage != null }
                .sortedBy { it.attemptDate }
            val count = subPapers.size
            val avg = if (count > 0) subPapers.map { it.percentage!! }.average() else null
            val highest = if (count > 0) subPapers.maxOf { it.percentage!! } else null
            val latest = if (count > 0) subPapers.last().percentage else null
            val trendDelta = if (count >= 2) {
                subPapers.last().percentage!! - subPapers[subPapers.size - 2].percentage!!
            } else null

            SubjectScoreStats(
                subjectId = subject.id,
                subjectName = subject.name,
                completedPapersCount = count,
                averagePercentage = avg,
                highestPercentage = highest,
                latestPercentage = latest,
                trendDelta = trendDelta
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Overall Exam Analytics
    val overallAverageScore: StateFlow<Double?> = completedPapers.combine(subjects) { papers, _ ->
        val valid = papers.mapNotNull { it.percentage }
        if (valid.isNotEmpty()) valid.average() else null
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val bestScore: StateFlow<Double?> = completedPapers.combine(subjects) { papers, _ ->
        val valid = papers.mapNotNull { it.percentage }
        if (valid.isNotEmpty()) valid.maxOrNull() else null
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val latestScore: StateFlow<Double?> = completedPapers.combine(subjects) { papers, _ ->
        val sorted = papers.filter { it.percentage != null }.sortedByDescending { it.attemptDate }
        sorted.firstOrNull()?.percentage
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val scoreDeltaFromPrevious: StateFlow<Double?> = completedPapers.combine(subjects) { papers, _ ->
        val sorted = papers.filter { it.percentage != null }.sortedByDescending { it.attemptDate }
        if (sorted.size >= 2) {
            sorted[0].percentage!! - sorted[1].percentage!!
        } else null
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Actionable rule-based suggestions
    val studySuggestions: StateFlow<List<StudySuggestion>> = combine(
        subjectProgressList,
        subjectScoreStats,
        pendingHomework
    ) { progressList, scoreStats, pendingHw ->
        val suggestions = mutableListOf<StudySuggestion>()

        // 1. Pending Homework check
        if (pendingHw.isNotEmpty()) {
            suggestions.add(
                StudySuggestion(
                    title = "Pending Homework (${pendingHw.size} tasks)",
                    description = "You have unfinished school tasks. Complete \"${pendingHw.first().title}\" today to avoid backlog.",
                    priority = SuggestionPriority.HIGH
                )
            )
        }

        // 2. Low chapter progress subjects
        val lowestProgress = progressList.filter { it.totalChapters > 0 }.minByOrNull { it.progressPercentage }
        if (lowestProgress != null && lowestProgress.progressPercentage < 50.0) {
            suggestions.add(
                StudySuggestion(
                    title = "Boost ${lowestProgress.subjectName} Syllabus",
                    description = "Current syllabus completion is ${String.format("%.1f", lowestProgress.progressPercentage)}%. Focus on NCERT reading and questions for remaining chapters.",
                    priority = SuggestionPriority.HIGH
                )
            )
        }

        // 3. Score trends
        val decliningSubject = scoreStats.find { it.trendDelta != null && it.trendDelta < -5.0 }
        if (decliningSubject != null) {
            suggestions.add(
                StudySuggestion(
                    title = "Review mistakes in ${decliningSubject.subjectName}",
                    description = "Recent attempt score dropped by ${String.format("%.1f", kotlin.math.abs(decliningSubject.trendDelta!!))}%. Analyze incorrect answers before next test.",
                    priority = SuggestionPriority.HIGH
                )
            )
        }

        // 4. Unattempted subjects
        val unattempted = scoreStats.filter { it.completedPapersCount == 0 }
        if (unattempted.isNotEmpty()) {
            suggestions.add(
                StudySuggestion(
                    title = "Practice Question Papers for ${unattempted.first().subjectName}",
                    description = "You haven't logged any completed sample papers for ${unattempted.first().subjectName}. Solve at least one paper under timed exam conditions.",
                    priority = SuggestionPriority.MEDIUM
                )
            )
        }

        // 5. Positive reinforcement
        val topScore = scoreStats.filter { (it.averagePercentage ?: 0.0) >= 80.0 }
        if (topScore.isNotEmpty()) {
            suggestions.add(
                StudySuggestion(
                    title = "Strong Momentum in ${topScore.first().subjectName}",
                    description = "Excellent average score of ${String.format("%.1f", topScore.first().averagePercentage!!)}%. Maintain revision through PYQs and CBT questions.",
                    priority = SuggestionPriority.LOW
                )
            )
        }

        if (suggestions.isEmpty()) {
            suggestions.add(
                StudySuggestion(
                    title = "All caught up!",
                    description = "Great consistency! Continue your daily homework and solve CBSE sample papers regularly.",
                    priority = SuggestionPriority.LOW
                )
            )
        }

        suggestions
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            studyRepo.checkAndSeedSyllabus()
            NotificationHelper.createNotificationChannel(application)
            // Schedule reminder if enabled
            val prefs = userPreferences.value
            NotificationHelper.scheduleDailyReminder(
                application,
                prefs.reminderHour,
                prefs.reminderMinute,
                prefs.isReminderEnabled
            )
        }
    }

    // User Profile Actions
    fun completeOnboarding(name: String) {
        userPrefsRepo.completeOnboarding(name)
    }

    fun updateStudentName(name: String) {
        userPrefsRepo.setStudentName(name)
    }

    fun updateTheme(theme: String) {
        userPrefsRepo.setThemeMode(theme)
    }

    fun updateReminderSettings(enabled: Boolean, hour: Int, minute: Int) {
        userPrefsRepo.setReminderEnabled(enabled)
        userPrefsRepo.setReminderTime(hour, minute)
        NotificationHelper.scheduleDailyReminder(getApplication(), hour, minute, enabled)
    }

    // Homework Actions
    fun addHomework(title: String, subject: String, notes: String, dueDate: Long?) {
        viewModelScope.launch {
            studyRepo.addHomework(title, subject, notes, dueDate)
        }
    }

    fun toggleHomework(homework: HomeworkEntity) {
        viewModelScope.launch {
            studyRepo.toggleHomework(homework)
        }
    }

    fun updateHomework(homework: HomeworkEntity) {
        viewModelScope.launch {
            studyRepo.updateHomework(homework)
        }
    }

    fun deleteHomework(id: Long) {
        viewModelScope.launch {
            studyRepo.deleteHomework(id)
        }
    }

    // Chapter Actions
    fun addChapter(subjectId: String, name: String, chapterNumber: Int?, notes: String) {
        viewModelScope.launch {
            studyRepo.addChapter(subjectId, name, chapterNumber, notes)
        }
    }

    fun updateChapter(chapter: ChapterEntity) {
        viewModelScope.launch {
            studyRepo.updateChapter(chapter)
        }
    }

    fun deleteChapter(chapterId: Long) {
        viewModelScope.launch {
            studyRepo.deleteChapter(chapterId)
        }
    }

    fun toggleChapterTask(task: ChapterTaskEntity) {
        viewModelScope.launch {
            studyRepo.toggleChapterTask(task)
        }
    }

    fun resetChapterChecklist(chapterId: Long) {
        viewModelScope.launch {
            studyRepo.resetChapterChecklist(chapterId)
        }
    }

    // Question Paper Actions
    fun addQuestionPaper(
        subjectId: String,
        paperName: String,
        maxMarks: Double,
        obtainedMarks: Double?,
        duration: Int?,
        notes: String,
        status: String
    ) {
        viewModelScope.launch {
            studyRepo.addQuestionPaper(
                subjectId = subjectId,
                paperName = paperName,
                maxMarks = maxMarks,
                obtainedMarks = obtainedMarks,
                attemptDate = System.currentTimeMillis(),
                durationMinutes = duration,
                notes = notes,
                status = status
            )
        }
    }

    fun updateQuestionPaper(paper: QuestionPaperEntity) {
        viewModelScope.launch {
            studyRepo.updateQuestionPaper(paper)
        }
    }

    fun deleteQuestionPaper(id: Long) {
        viewModelScope.launch {
            studyRepo.deleteQuestionPaper(id)
        }
    }

    // Backup & Restore
    suspend fun exportBackupJson(): String {
        val studentName = userPreferences.value.studentName
        val backup = studyRepo.createBackup(studentName, "1.0")
        return BackupManager.exportToJson(backup)
    }

    suspend fun importBackupJson(jsonString: String, replaceExisting: Boolean): Result<Unit> {
        val parseResult = BackupManager.parseBackupJson(jsonString)
        return if (parseResult.isSuccess) {
            val backup = parseResult.getOrThrow()
            studyRepo.restoreBackup(backup, replaceExisting)
            if (backup.studentName.isNotBlank()) {
                userPrefsRepo.setStudentName(backup.studentName)
            }
            Result.success(Unit)
        } else {
            Result.failure(parseResult.exceptionOrNull() ?: Exception("Unknown error parsing backup"))
        }
    }

    fun resetAllData() {
        viewModelScope.launch {
            studyRepo.resetAllData()
            userPrefsRepo.resetPreferences()
        }
    }
}
