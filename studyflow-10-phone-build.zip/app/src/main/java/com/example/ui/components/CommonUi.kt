package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.QuestionPaperEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun StatMetricCard(
    title: String,
    value: String,
    subtitle: String? = null,
    icon: ImageVector,
    iconTint: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp
    ) {
        Column(
            modifier = Modifier.padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(iconTint.copy(alpha = 0.12f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconTint,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = value,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Text(
                text = title,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (subtitle != null) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = iconTint
                )
            }
        }
    }
}

@Composable
fun ConfirmationDialog(
    title: String,
    message: String,
    confirmButtonText: String = "Delete",
    isDestructive: Boolean = true,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(text = title, fontWeight = FontWeight.Bold)
        },
        text = {
            Text(text = message, style = MaterialTheme.typography.bodyMedium)
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirm()
                    onDismiss()
                },
                colors = if (isDestructive) {
                    ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                } else {
                    ButtonDefaults.buttonColors()
                },
                modifier = Modifier.testTag("confirm_dialog_action_button")
            ) {
                Text(confirmButtonText)
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_dialog_action_button")
            ) {
                Text("Cancel")
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddHomeworkDialog(
    subjects: List<String>,
    onAddHomework: (title: String, subject: String, notes: String, dueDate: Long?) -> Unit,
    onDismiss: () -> Unit
) {
    var title by remember { mutableStateOf("") }
    var selectedSubject by remember { mutableStateOf(if (subjects.isNotEmpty()) subjects.first() else "General") }
    var notes by remember { mutableStateOf("") }
    var isSubjectExpanded by remember { mutableStateOf(false) }
    var titleError by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(text = "+ New Homework", fontWeight = FontWeight.Bold)
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = {
                        title = it
                        if (it.isNotBlank()) titleError = false
                    },
                    label = { Text("Homework Title *") },
                    isError = titleError,
                    supportingText = if (titleError) {
                        { Text("Homework title is required") }
                    } else null,
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("homework_title_input")
                )

                // Subject selection
                ExposedDropdownMenuBox(
                    expanded = isSubjectExpanded,
                    onExpandedChange = { isSubjectExpanded = !isSubjectExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedSubject,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Subject (Optional)") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isSubjectExpanded) },
                        modifier = Modifier
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = isSubjectExpanded,
                        onDismissRequest = { isSubjectExpanded = false }
                    ) {
                        subjects.forEach { subject ->
                            DropdownMenuItem(
                                text = { Text(subject) },
                                onClick = {
                                    selectedSubject = subject
                                    isSubjectExpanded = false
                                }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes / Chapter Details (Optional)") },
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )

                Text(
                    text = "Created: Today (${SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())})",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isBlank()) {
                        titleError = true
                    } else {
                        onAddHomework(title, selectedSubject, notes, null)
                        onDismiss()
                    }
                },
                modifier = Modifier.testTag("submit_homework_button")
            ) {
                Text("Add Homework")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun AddChapterDialog(
    subjectName: String,
    onAddChapter: (name: String, chapterNumber: Int?, notes: String) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var chapterNumberText by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var nameError by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(text = "Add Chapter to $subjectName", fontWeight = FontWeight.Bold)
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = {
                        name = it
                        if (it.isNotBlank()) nameError = false
                    },
                    label = { Text("Chapter Name *") },
                    isError = nameError,
                    supportingText = if (nameError) {
                        { Text("Chapter name cannot be empty") }
                    } else null,
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("chapter_name_input")
                )

                OutlinedTextField(
                    value = chapterNumberText,
                    onValueChange = { chapterNumberText = it },
                    label = { Text("Chapter Number (Optional)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Key Topics / Notes (Optional)") },
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )

                Text(
                    text = "All 7 preparation tasks (NCERT Reading, Lecture, PYQs, etc.) will be automatically generated.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isBlank()) {
                        nameError = true
                    } else {
                        val num = chapterNumberText.toIntOrNull()
                        onAddChapter(name, num, notes)
                        onDismiss()
                    }
                },
                modifier = Modifier.testTag("submit_chapter_button")
            ) {
                Text("Add Chapter")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddQuestionPaperDialog(
    defaultSubjectId: String,
    subjects: List<Pair<String, String>>, // (id, name)
    onAddPaper: (
        subjectId: String,
        paperName: String,
        maxMarks: Double,
        obtainedMarks: Double?,
        duration: Int?,
        notes: String,
        status: String
    ) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedSubjectId by remember { mutableStateOf(defaultSubjectId) }
    var paperName by remember { mutableStateOf("") }
    var maxMarksText by remember { mutableStateOf("80") }
    var obtainedMarksText by remember { mutableStateOf("") }
    var durationText by remember { mutableStateOf("180") }
    var notes by remember { mutableStateOf("") }
    var status by remember { mutableStateOf(QuestionPaperEntity.STATUS_NOT_STARTED) }

    var paperNameError by remember { mutableStateOf(false) }
    var marksError by remember { mutableStateOf<String?>(null) }
    var isSubjectExpanded by remember { mutableStateOf(false) }

    val currentSubjectName = subjects.find { it.first == selectedSubjectId }?.second ?: "Subject"

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(text = "+ New Question Paper", fontWeight = FontWeight.Bold)
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Subject Dropdown
                ExposedDropdownMenuBox(
                    expanded = isSubjectExpanded,
                    onExpandedChange = { isSubjectExpanded = !isSubjectExpanded }
                ) {
                    OutlinedTextField(
                        value = currentSubjectName,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Subject") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isSubjectExpanded) },
                        modifier = Modifier
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = isSubjectExpanded,
                        onDismissRequest = { isSubjectExpanded = false }
                    ) {
                        subjects.forEach { (id, name) ->
                            DropdownMenuItem(
                                text = { Text(name) },
                                onClick = {
                                    selectedSubjectId = id
                                    isSubjectExpanded = false
                                }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = paperName,
                    onValueChange = {
                        paperName = it
                        if (it.isNotBlank()) paperNameError = false
                    },
                    label = { Text("Paper Name * (e.g. CBSE 2024 Sample Paper)") },
                    isError = paperNameError,
                    supportingText = if (paperNameError) {
                        { Text("Paper name is required") }
                    } else null,
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("paper_name_input")
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = maxMarksText,
                        onValueChange = { maxMarksText = it },
                        label = { Text("Max Marks *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedTextField(
                        value = obtainedMarksText,
                        onValueChange = {
                            obtainedMarksText = it
                            if (it.isNotBlank()) {
                                status = QuestionPaperEntity.STATUS_COMPLETED
                            }
                        },
                        label = { Text("Marks (Opt)") },
                        placeholder = { Text("e.g. 72.5") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                if (marksError != null) {
                    Text(
                        text = marksError!!,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                OutlinedTextField(
                    value = durationText,
                    onValueChange = { durationText = it },
                    label = { Text("Duration in Minutes (e.g. 180)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // Status Chips
                Text(
                    text = "Attempt Status:",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        QuestionPaperEntity.STATUS_NOT_STARTED,
                        QuestionPaperEntity.STATUS_IN_PROGRESS,
                        QuestionPaperEntity.STATUS_COMPLETED
                    ).forEach { s ->
                        FilterChip(
                            selected = status == s,
                            onClick = { status = s },
                            label = { Text(s, fontSize = 12.sp) }
                        )
                    }
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes / Weak Areas (Optional)") },
                    maxLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    marksError = null
                    if (paperName.isBlank()) {
                        paperNameError = true
                        return@Button
                    }
                    val maxMarks = maxMarksText.toDoubleOrNull()
                    if (maxMarks == null || maxMarks <= 0) {
                        marksError = "Maximum marks must be greater than 0"
                        return@Button
                    }
                    val obtainedMarks = if (obtainedMarksText.isNotBlank()) {
                        val parsed = obtainedMarksText.toDoubleOrNull()
                        if (parsed == null || parsed < 0 || parsed > maxMarks) {
                            marksError = "Obtained marks must be between 0 and $maxMarks"
                            return@Button
                        }
                        parsed
                    } else null

                    val duration = durationText.toIntOrNull()

                    val finalStatus = if (obtainedMarks != null) {
                        QuestionPaperEntity.STATUS_COMPLETED
                    } else status

                    onAddPaper(
                        selectedSubjectId,
                        paperName,
                        maxMarks,
                        obtainedMarks,
                        duration,
                        notes,
                        finalStatus
                    )
                    onDismiss()
                },
                modifier = Modifier.testTag("submit_paper_button")
            ) {
                Text("Save Paper")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
