package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.outlined.Assignment
import androidx.compose.material.icons.outlined.AssignmentTurnedIn
import androidx.compose.material.icons.outlined.AutoStories
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.PendingActions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.HomeworkEntity
import com.example.data.model.QuestionPaperEntity
import com.example.ui.components.StatMetricCard
import com.example.ui.components.getSubjectColor
import com.example.ui.theme.AiColor
import com.example.ui.theme.EnglishColor
import com.example.ui.theme.HindiColor
import com.example.ui.theme.MathColor
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.ScienceColor
import com.example.ui.theme.SstColor
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.VioletAccent
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.SubjectProgressItem
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DashboardScreen(
    studentName: String,
    allHomework: List<HomeworkEntity>,
    pendingHomework: List<HomeworkEntity>,
    completedHomework: List<HomeworkEntity>,
    overallChapterProgress: Double,
    questionPapers: List<QuestionPaperEntity>,
    subjectProgressList: List<SubjectProgressItem>,
    onToggleHomework: (HomeworkEntity) -> Unit,
    onQuickAddHomework: () -> Unit,
    onQuickAddChapter: () -> Unit,
    onQuickAddPaper: () -> Unit,
    onNavigateToHomework: () -> Unit,
    onNavigateToChapters: () -> Unit,
    onNavigateToPapers: () -> Unit,
    onNavigateToAnalytics: () -> Unit
) {
    val todayDateFormatted = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date())

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome Header Banner
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.primaryContainer,
                tonalElevation = 2.dp
            ) {
                Column(
                    modifier = Modifier.padding(20.dp)
                ) {
                    Text(
                        text = todayDateFormatted,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f),
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (studentName.isNotBlank()) "Welcome back, $studentName!" else "Welcome to StudyFlow 10!",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Class 10 CBSE Board Prep • Focus on daily goals",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                    )
                }
            }
        }

        // Quick Action Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuickActionButton(
                    label = "+ Homework",
                    icon = Icons.Default.Add,
                    onClick = onQuickAddHomework,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("quick_add_homework_btn")
                )
                QuickActionButton(
                    label = "+ Chapter",
                    icon = Icons.Default.Add,
                    onClick = onQuickAddChapter,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("quick_add_chapter_btn")
                )
                QuickActionButton(
                    label = "+ Paper",
                    icon = Icons.Default.Add,
                    onClick = onQuickAddPaper,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("quick_add_paper_btn")
                )
            }
        }

        // Key Study Statistics Grid
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatMetricCard(
                        title = "Pending Homework",
                        value = "${pendingHomework.size}",
                        subtitle = if (pendingHomework.isNotEmpty()) "Needs attention" else "All completed!",
                        icon = Icons.Outlined.PendingActions,
                        iconTint = if (pendingHomework.isNotEmpty()) WarningAmber else SuccessGreen,
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onNavigateToHomework() }
                    )

                    StatMetricCard(
                        title = "Syllabus Done",
                        value = "${String.format("%.1f", overallChapterProgress)}%",
                        subtitle = "7 steps per chapter",
                        icon = Icons.Outlined.AutoStories,
                        iconTint = VioletAccent,
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onNavigateToChapters() }
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatMetricCard(
                        title = "Papers Attempted",
                        value = "${questionPapers.size}",
                        subtitle = "${questionPapers.count { it.status == QuestionPaperEntity.STATUS_COMPLETED }} completed",
                        icon = Icons.Outlined.Description,
                        iconTint = NavyPrimary,
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onNavigateToPapers() }
                    )

                    StatMetricCard(
                        title = "Homework Total",
                        value = "${allHomework.size}",
                        subtitle = "${completedHomework.size} finished",
                        icon = Icons.Outlined.AssignmentTurnedIn,
                        iconTint = SuccessGreen,
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onNavigateToHomework() }
                    )
                }
            }
        }

        // Section: Tasks That Need Attention (Pending Homework)
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 2.dp
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Tasks Needing Attention",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            if (pendingHomework.isNotEmpty()) {
                                Spacer(modifier = Modifier.width(8.dp))
                                Box(
                                    modifier = Modifier
                                        .background(WarningAmber.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "${pendingHomework.size} Pending",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = WarningAmber
                                    )
                                }
                            }
                        }

                        Text(
                            text = "View All",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.clickable { onNavigateToHomework() }
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (pendingHomework.isEmpty()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.CheckCircle,
                                contentDescription = null,
                                tint = SuccessGreen,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "Zero pending tasks! Tap '+ Homework' above to add schoolwork.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            pendingHomework.take(4).forEach { hw ->
                                PendingHomeworkQuickItem(
                                    homework = hw,
                                    onToggle = { onToggleHomework(hw) }
                                )
                            }
                        }
                    }
                }
            }
        }

        // Section: Subject-Wise Syllabus Readiness
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 2.dp
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Subject Syllabus Overview",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Chapters",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.clickable { onNavigateToChapters() }
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    subjectProgressList.forEach { item ->
                        SubjectProgressRow(
                            item = item,
                            onClick = onNavigateToChapters
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }
            }
        }

        // Section: Recent Question Paper Results
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 2.dp
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Recent Test Attempts",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Analytics",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.clickable { onNavigateToAnalytics() }
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    val attempted = questionPapers.take(3)
                    if (attempted.isEmpty()) {
                        Text(
                            text = "No question papers attempted yet. Tap '+ Paper' to record your sample test marks and monitor progress.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 20.sp
                        )
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            attempted.forEach { paper ->
                                RecentPaperRow(paper = paper)
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun QuickActionButton(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    FilledTonalButton(
        onClick = onClick,
        modifier = modifier.height(44.dp),
        shape = RoundedCornerShape(12.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1
        )
    }
}

@Composable
private fun PendingHomeworkQuickItem(
    homework: HomeworkEntity,
    onToggle: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            .clickable { onToggle() }
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(
            checked = homework.isCompleted,
            onCheckedChange = { onToggle() }
        )
        Spacer(modifier = Modifier.width(4.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = homework.title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (homework.subject.isNotBlank()) {
                Text(
                    text = homework.subject,
                    style = MaterialTheme.typography.labelSmall,
                    color = getSubjectColor(homework.subject)
                )
            }
        }
    }
}

@Composable
private fun SubjectProgressRow(
    item: SubjectProgressItem,
    onClick: () -> Unit
) {
    val barColor = getSubjectColor(item.subjectName)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = item.subjectName,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "${String.format("%.0f", item.progressPercentage)}% (${item.completedTasks}/${item.totalTasks})",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = barColor
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { (item.progressPercentage / 100.0).toFloat().coerceIn(0f, 1f) },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = barColor,
            trackColor = MaterialTheme.colorScheme.surfaceVariant
        )
    }
}

@Composable
private fun RecentPaperRow(paper: QuestionPaperEntity) {
    val dateStr = SimpleDateFormat("dd MMM", Locale.getDefault()).format(Date(paper.attemptDate))
    val subColor = getSubjectColor(paper.subjectId)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            .padding(10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = paper.paperName,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "$dateStr • ${paper.subjectId}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        if (paper.percentage != null) {
            Box(
                modifier = Modifier
                    .background(subColor.copy(alpha = 0.12f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "${String.format("%.1f", paper.percentage)}% (${paper.obtainedMarks}/${paper.maxMarks})",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = subColor
                )
            }
        } else {
            Text(
                text = paper.status,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
