package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoStories
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.EmojiEvents
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Lightbulb
import androidx.compose.material.icons.outlined.Score
import androidx.compose.material.icons.outlined.TrendingDown
import androidx.compose.material.icons.outlined.TrendingUp
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.QuestionPaperEntity
import com.example.ui.components.ChapterCompletionList
import com.example.ui.components.ScoreTrendChart
import com.example.ui.components.StatMetricCard
import com.example.ui.components.SubjectBarChart
import com.example.ui.components.getSubjectColor
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.VioletAccent
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.StudySuggestion
import com.example.ui.viewmodel.SubjectProgressItem
import com.example.ui.viewmodel.SubjectScoreStats
import com.example.ui.viewmodel.SuggestionPriority
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AnalyticsScreen(
    overallAverageScore: Double?,
    bestScore: Double?,
    latestScore: Double?,
    scoreDelta: Double?,
    completedPapers: List<QuestionPaperEntity>,
    overallChapterProgress: Double,
    subjectProgressList: List<SubjectProgressItem>,
    subjectScoreStats: List<SubjectScoreStats>,
    suggestions: List<StudySuggestion>
) {
    val barChartData = subjectScoreStats
        .filter { it.averagePercentage != null }
        .map { Pair(it.subjectName, it.averagePercentage!!) }

    val trendData = completedPapers
        .filter { it.percentage != null }
        .sortedBy { it.attemptDate }
        .map { paper ->
            val dateLabel = SimpleDateFormat("dd/MM", Locale.getDefault()).format(Date(paper.attemptDate))
            Pair(dateLabel, paper.percentage!!)
        }

    val chapterProgressData = subjectProgressList.map {
        Pair(it.subjectName, it.progressPercentage)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Performance Analytics",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "Data-driven insights to guide your Class 10 Board Exam preparation.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Key Overall Metrics Grid
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatMetricCard(
                        title = "Overall Average",
                        value = if (overallAverageScore != null) "${String.format("%.1f", overallAverageScore)}%" else "—",
                        subtitle = "${completedPapers.size} tests finished",
                        icon = Icons.Outlined.Score,
                        iconTint = NavyPrimary,
                        modifier = Modifier.weight(1f)
                    )

                    StatMetricCard(
                        title = "Best Test Score",
                        value = if (bestScore != null) "${String.format("%.1f", bestScore)}%" else "—",
                        subtitle = "Personal record",
                        icon = Icons.Outlined.EmojiEvents,
                        iconTint = SuccessGreen,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatMetricCard(
                        title = "Latest Attempt",
                        value = if (latestScore != null) "${String.format("%.1f", latestScore)}%" else "—",
                        subtitle = if (scoreDelta != null) {
                            if (scoreDelta >= 0) "+${String.format("%.1f", scoreDelta)}% vs previous" else "${String.format("%.1f", scoreDelta)}% vs previous"
                        } else "No previous test",
                        icon = if (scoreDelta != null && scoreDelta >= 0) Icons.Outlined.TrendingUp else Icons.Outlined.TrendingDown,
                        iconTint = if (scoreDelta != null && scoreDelta >= 0) SuccessGreen else if (scoreDelta != null) MaterialTheme.colorScheme.error else NavyPrimary,
                        modifier = Modifier.weight(1f)
                    )

                    StatMetricCard(
                        title = "Syllabus Finished",
                        value = "${String.format("%.1f", overallChapterProgress)}%",
                        subtitle = "7 steps per chapter",
                        icon = Icons.Outlined.AutoStories,
                        iconTint = VioletAccent,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Native Canvas Charts
        item {
            SubjectBarChart(data = barChartData)
        }

        item {
            ScoreTrendChart(scores = trendData)
        }

        item {
            ChapterCompletionList(data = chapterProgressData)
        }

        // Detailed Subject-Wise Breakdown
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 2.dp
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Subject Performance Breakdown",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    subjectScoreStats.forEach { stat ->
                        SubjectDetailStatRow(stat = stat)
                        Spacer(modifier = Modifier.height(10.dp))
                    }
                }
            }
        }

        // Rule-Based Smart Improvement Suggestions
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 2.dp
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Lightbulb,
                            contentDescription = null,
                            tint = WarningAmber,
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = "Targeted Study Recommendations",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    suggestions.forEach { suggestion ->
                        SuggestionCard(suggestion = suggestion)
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }
            }
        }

        // Disclaimer Note
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Info,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Notice: Performance statistics describe recorded practice and mock question papers, not a guaranteed board exam result. Regular practice under real timed conditions provides the most accurate self-evaluation.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 18.sp
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun SubjectDetailStatRow(stat: SubjectScoreStats) {
    val subColor = getSubjectColor(stat.subjectName)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = stat.subjectName,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = if (stat.completedPapersCount > 0) "${stat.completedPapersCount} papers completed" else "No papers completed yet",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        if (stat.averagePercentage != null) {
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${String.format("%.1f", stat.averagePercentage)}% avg",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = subColor
                )
                Text(
                    text = "High: ${String.format("%.1f", stat.highestPercentage ?: 0.0)}%",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            Text(
                text = "No data",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun SuggestionCard(suggestion: StudySuggestion) {
    val tagColor = when (suggestion.priority) {
        SuggestionPriority.HIGH -> WarningAmber
        SuggestionPriority.MEDIUM -> NavyPrimary
        SuggestionPriority.LOW -> SuccessGreen
    }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        color = tagColor.copy(alpha = 0.08f)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = suggestion.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Box(
                    modifier = Modifier
                        .background(tagColor.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = suggestion.priority.name,
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = tagColor
                    )
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = suggestion.description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 18.sp
            )
        }
    }
}
