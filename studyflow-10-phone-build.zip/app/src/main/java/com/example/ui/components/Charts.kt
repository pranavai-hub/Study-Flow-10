package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.ShowChart
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AiColor
import com.example.ui.theme.EnglishColor
import com.example.ui.theme.HindiColor
import com.example.ui.theme.MathColor
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.ScienceColor
import com.example.ui.theme.SstColor
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.VioletAccent

fun getSubjectColor(subjectName: String): Color {
    val lower = subjectName.lowercase()
    return when {
        lower.contains("math") -> MathColor
        lower.contains("sci") -> ScienceColor
        lower.contains("sst") || lower.contains("social") -> SstColor
        lower.contains("eng") -> EnglishColor
        lower.contains("hin") -> HindiColor
        lower.contains("ai") || lower.contains("artif") -> AiColor
        else -> NavyPrimary
    }
}

fun getSubjectShortLabel(subjectName: String): String {
    val lower = subjectName.lowercase()
    return when {
        lower.contains("math") -> "Math"
        lower.contains("sci") -> "Science"
        lower.contains("sst") || lower.contains("social") -> "SST"
        lower.contains("eng") -> "English"
        lower.contains("hin") -> "Hindi"
        lower.contains("ai") || lower.contains("artif") -> "AI"
        else -> subjectName.take(5)
    }
}

@Composable
fun SubjectBarChart(
    data: List<Pair<String, Double>>, // (Subject, Avg Percentage)
    modifier: Modifier = Modifier
) {
    if (data.isEmpty() || data.all { it.second == 0.0 }) {
        EmptyChartCard(
            title = "Subject-Wise Test Average",
            message = "No completed question papers yet. Practice tests to see your subject comparison."
        )
        return
    }

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Subject-Wise Test Average",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "Calculated from completed question papers",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(16.dp))

            val outlineColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
            val textColor = MaterialTheme.colorScheme.onSurfaceVariant

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
            ) {
                Canvas(modifier = Modifier.matchParentSize()) {
                    val w = size.width
                    val h = size.height - 30.dp.toPx() // leave space for labels
                    val barCount = data.size
                    if (barCount == 0) return@Canvas

                    // Draw horizontal guide lines (0%, 25%, 50%, 75%, 100%)
                    val levels = listOf(0.0, 25.0, 50.0, 75.0, 100.0)
                    levels.forEach { level ->
                        val y = h - (level.toFloat() / 100f * h)
                        drawLine(
                            color = outlineColor,
                            start = Offset(0f, y),
                            end = Offset(w, y),
                            strokeWidth = 1.dp.toPx(),
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f), 0f)
                        )
                    }

                    val slotWidth = w / barCount
                    val barWidth = (slotWidth * 0.55f).coerceAtMost(36.dp.toPx())

                    data.forEachIndexed { index, (subject, percentage) ->
                        val barColor = getSubjectColor(subject)
                        val barHeight = ((percentage.coerceIn(0.0, 100.0) / 100.0) * h).toFloat()
                        val x = index * slotWidth + (slotWidth - barWidth) / 2f
                        val y = h - barHeight

                        // Draw Bar
                        if (barHeight > 0) {
                            drawRoundRect(
                                color = barColor,
                                topLeft = Offset(x, y),
                                size = Size(barWidth, barHeight),
                                cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
                            )
                        }

                        // Draw baseline
                        drawLine(
                            color = outlineColor,
                            start = Offset(0f, h),
                            end = Offset(w, h),
                            strokeWidth = 2.dp.toPx()
                        )
                    }
                }

                // Render Labels below Canvas
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .height(28.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    data.forEach { (subject, percentage) ->
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = String.format("%.0f%%", percentage),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = getSubjectColor(subject)
                            )
                            Text(
                                text = getSubjectShortLabel(subject),
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 10.sp,
                                maxLines = 1,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ScoreTrendChart(
    scores: List<Pair<String, Double>>, // (Date/Paper, Score Percentage)
    modifier: Modifier = Modifier
) {
    if (scores.size < 2) {
        EmptyChartCard(
            title = "Score Progress Trend",
            message = "Complete at least 2 question papers to view your score progression and trendline."
        )
        return
    }

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Score Progress Trend",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Recent test scores in chronological order",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                val lastScore = scores.last().second
                val firstScore = scores.first().second
                val diff = lastScore - firstScore
                val diffColor = if (diff >= 0) SuccessGreen else MaterialTheme.colorScheme.error

                Box(
                    modifier = Modifier
                        .background(diffColor.copy(alpha = 0.12f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (diff >= 0) "+${String.format("%.1f", diff)}%" else "${String.format("%.1f", diff)}%",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = diffColor
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            val primaryColor = NavyPrimary
            val gridColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
            ) {
                Canvas(modifier = Modifier.matchParentSize()) {
                    val w = size.width
                    val h = size.height - 24.dp.toPx()
                    val pointCount = scores.size
                    val stepX = w / (pointCount - 1).coerceAtLeast(1)

                    // Target guide line (80% Distinction)
                    val targetY = h - (80f / 100f * h)
                    drawLine(
                        color = SuccessGreen.copy(alpha = 0.6f),
                        start = Offset(0f, targetY),
                        end = Offset(w, targetY),
                        strokeWidth = 1.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                    )

                    // Calculate points
                    val points = scores.mapIndexed { index, (_, score) ->
                        val x = index * stepX
                        val y = h - ((score.coerceIn(0.0, 100.0) / 100.0) * h).toFloat()
                        Offset(x, y)
                    }

                    // Build path and gradient area
                    val path = Path()
                    val fillPath = Path()

                    points.forEachIndexed { i, pt ->
                        if (i == 0) {
                            path.moveTo(pt.x, pt.y)
                            fillPath.moveTo(pt.x, h)
                            fillPath.lineTo(pt.x, pt.y)
                        } else {
                            val prev = points[i - 1]
                            val cx1 = prev.x + (pt.x - prev.x) / 2
                            val cy1 = prev.y
                            val cx2 = prev.x + (pt.x - prev.x) / 2
                            val cy2 = pt.y
                            path.cubicTo(cx1, cy1, cx2, cy2, pt.x, pt.y)
                            fillPath.cubicTo(cx1, cy1, cx2, cy2, pt.x, pt.y)
                        }
                    }
                    fillPath.lineTo(points.last().x, h)
                    fillPath.close()

                    // Fill gradient
                    drawPath(
                        path = fillPath,
                        brush = Brush.verticalGradient(
                            colors = listOf(primaryColor.copy(alpha = 0.28f), primaryColor.copy(alpha = 0.02f)),
                            startY = 0f,
                            endY = h
                        )
                    )

                    // Draw line
                    drawPath(
                        path = path,
                        color = primaryColor,
                        style = Stroke(width = 3.dp.toPx())
                    )

                    // Draw data dots
                    points.forEachIndexed { index, pt ->
                        drawCircle(
                            color = primaryColor,
                            radius = 4.5.dp.toPx(),
                            center = pt
                        )
                        drawCircle(
                            color = Color.White,
                            radius = 2.dp.toPx(),
                            center = pt
                        )
                    }
                }

                // Range labels
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = scores.first().first,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "80% Target",
                        style = MaterialTheme.typography.labelSmall,
                        color = SuccessGreen
                    )
                    Text(
                        text = scores.last().first,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun ChapterCompletionList(
    data: List<Pair<String, Double>>, // (Subject, Completion %)
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Syllabus Completion by Subject",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "Based on the 7 preparation steps per chapter",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(16.dp))

            data.forEach { (subject, progress) ->
                val barColor = getSubjectColor(subject)
                Column(modifier = Modifier.padding(vertical = 6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = subject,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = String.format("%.1f%%", progress),
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = barColor
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .background(
                                MaterialTheme.colorScheme.surfaceVariant,
                                RoundedCornerShape(4.dp)
                            )
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(fraction = (progress / 100.0).toFloat().coerceIn(0f, 1f))
                                .height(8.dp)
                                .background(barColor, RoundedCornerShape(4.dp))
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyChartCard(
    title: String,
    message: String
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 1.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Outlined.BarChart,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f),
                modifier = Modifier.size(36.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = message,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 18.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    }
}
