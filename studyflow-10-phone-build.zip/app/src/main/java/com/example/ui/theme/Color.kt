package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Colors
val NavyPrimary = Color(0xFF1D4ED8)
val NavyOnPrimary = Color(0xFFFFFFFF)
val NavyPrimaryContainer = Color(0xFFDBEAFE)
val NavyOnPrimaryContainer = Color(0xFF1E3A8A)

val SlateSecondary = Color(0xFF334155)
val SlateOnSecondary = Color(0xFFFFFFFF)
val SlateSecondaryContainer = Color(0xFFF1F5F9)
val SlateOnSecondaryContainer = Color(0xFF0F172A)

val VioletAccent = Color(0xFF7C3AED)
val VioletOnAccent = Color(0xFFFFFFFF)
val VioletAccentContainer = Color(0xFFEDE9FE)
val VioletOnAccentContainer = Color(0xFF4C1D95)

val BackgroundLight = Color(0xFFF8FAFC)
val OnBackgroundLight = Color(0xFF0F172A)
val SurfaceLight = Color(0xFFFFFFFF)
val OnSurfaceLight = Color(0xFF0F172A)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val OnSurfaceVariantLight = Color(0xFF475569)
val OutlineLight = Color(0xFFCBD5E1)

// Dark Colors
val NavyPrimaryDark = Color(0xFF60A5FA)
val NavyOnPrimaryDark = Color(0xFF0F172A)
val NavyPrimaryContainerDark = Color(0xFF1E3A8A)
val NavyOnPrimaryContainerDark = Color(0xFFDBEAFE)

val SlateSecondaryDark = Color(0xFF94A3B8)
val SlateOnSecondaryDark = Color(0xFF0F172A)
val SlateSecondaryContainerDark = Color(0xFF1E293B)
val SlateOnSecondaryContainerDark = Color(0xFFF8FAFC)

val VioletAccentDark = Color(0xFFA78BFA)
val VioletOnAccentDark = Color(0xFF2E1065)
val VioletAccentContainerDark = Color(0xFF4C1D95)
val VioletOnAccentContainerDark = Color(0xFFEDE9FE)

val BackgroundDark = Color(0xFF0B0F19)
val OnBackgroundDark = Color(0xFFF1F5F9)
val SurfaceDark = Color(0xFF131926)
val OnSurfaceDark = Color(0xFFF1F5F9)
val SurfaceVariantDark = Color(0xFF1E2738)
val OnSurfaceVariantDark = Color(0xFF94A3B8)
val OutlineDark = Color(0xFF334155)

// Status & Indicators
val SuccessGreen = Color(0xFF10B981)
val WarningAmber = Color(0xFFF59E0B)
val ErrorRed = Color(0xFFEF4444)
val InfoSky = Color(0xFF0EA5E9)

// Subject Badge Colors
val MathColor = Color(0xFF2563EB)
val ScienceColor = Color(0xFF059669)
val SstColor = Color(0xFFD97706)
val EnglishColor = Color(0xFF7C3AED)
val HindiColor = Color(0xFFDC2626)
val AiColor = Color(0xFF0284C7)
