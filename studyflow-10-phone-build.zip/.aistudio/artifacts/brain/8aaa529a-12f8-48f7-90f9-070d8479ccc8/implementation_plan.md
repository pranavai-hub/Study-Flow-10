# StudyFlow 10 — Class 10 CBSE Board Exam Preparation Suite

StudyFlow 10 is a native Android study companion built with Kotlin, Jetpack Compose, Material 3, and Room SQLite database, engineered specifically for Class 10 CBSE Board Exam preparation (2026–27 session). It provides 100% offline, private tracking for daily homework, comprehensive 7-stage chapter preparation across 6 subjects, question paper attempts with score analytics, and study habit insights.

## User Review & Critical Decisions

> [!IMPORTANT]
> The following user preferences were confirmed during the interactive clarification phase and have been incorporated into this architecture:

- **Confirmed Decision 1: Pre-loaded CBSE Class 10 Syllabus**: The application will automatically seed the standard Class 10 CBSE NCERT syllabus for all 6 subjects (Mathematics, Science, Social Science, English, Hindi, and Artificial Intelligence). Students can also add, edit, or remove custom chapters at any time.
- **Confirmed Decision 2: Daily After-School Reminder**: The optional daily notification reminder is configured for **4:30 PM** by default (customizable in Settings), helping students review homework immediately after school.
- **Confirmed Decision 3: Clean Question Paper Slate**: Question papers will initialize completely empty, ready for real student attempts with verified score inputs and no synthetic placeholders.
- **Confirmed Decision 4: Device & Performance Target**: Engineered for peak responsiveness on Xiaomi Redmi 9 Power and modern Android devices (minSdk 24, Android 7.0+ through Android 14/15/16).

---

## 1. Overview & Core Concept

- **What It Does**: A complete, single-device study command center that remembers daily school tasks, systematically guides students through the complete 7-stage CBSE chapter workflow (NCERT Reading, Lecture, NCERT Questions, PYQ, CBT Questions, Hard-Level Questions, Sample Papers), logs test scores, and visualizes performance trends with native Compose charts.
- **Target Audience / Persona**: Class 10 CBSE students preparing for board exams who need a distraction-free, privacy-preserving, zero-login study tracker on their personal Android phones.
- **Key Value**: Replaces scattered paper diaries and chaotic WhatsApp homework groups with an organized, permanent local system that quantifies exam readiness and identifies specific chapters or subjects needing reinforcement.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **First-Launch Onboarding**:
   - Modern welcoming screen with a hero illustration banner.
   - Friendly greeting: *"Welcome to StudyFlow 10!"* with subtitle: *"Your personal companion for Class 10 Board Exam preparation."*
   - Name input field (*"What should we call you?"*) with real-time whitespace validation.
   - Smooth animated transition directly into the Dashboard personalized with *"Welcome back, [Name]!"*.
2. **Dashboard Command Center**:
   - Live date display (e.g., *"Monday, Nov 2"*).
   - Metric overview cards: Total Homework, Pending Tasks (highlighted), Completed Tasks, Overall Syllabus Progress %, and Papers Attempted.
   - Priority attention rail showing impending homework and lowest-progress chapters.
   - Floating / quick action buttons to instantly log homework, chapter progress, or new test results.
3. **Daily Homework Management**:
   - Fast one-tap dialog or sheet: Title (required), Subject chip selector (optional), Due Date picker (optional), and Notes (optional).
   - Interactive checkbox: immediate reactive toggle with ripple feedback, moving item between Pending and Completed states.
   - Filter chips: *All*, *Pending*, *Completed*, plus destructive swipe/button action with confirmation dialog.
4. **Chapter Mastery Tracker (6 Subjects)**:
   - High-contrast subject selector cards: Mathematics, Science, Social Science (SST), English, Hindi, Artificial Intelligence (AI).
   - Subject-level progress rings and chapter counts.
   - Chapter detail view featuring the mandatory 7 CBSE preparation stages:
     1. NCERT Reading
     2. Lecture
     3. NCERT Questions
     4. PYQ (Previous Year Questions)
     5. CBT Questions (Competency-Based Test Questions)
     6. Hard-Level Questions
     7. Sample Paper Practice
   - Progress bar updates reactively: `(Completed Tasks / Total Tasks) * 100%`.
   - Capabilities to add custom chapters, edit chapter numbers/notes, and reset progress with explicit confirmation.
5. **Question Paper Manager**:
   - Filtered by subject with test history cards sorted by most recent attempt.
   - Add/Edit Paper dialog: Paper Name, Subject, Maximum Marks (validated > 0), Obtained Marks (supports decimals, bounded between 0 and Max), Attempt Date, Duration, and Notes.
   - Automatic percentage calculation and status badges (*Not Started*, *In Progress*, *Completed*).
6. **Data-Driven Performance Analytics**:
   - Overall examination metrics: Total papers completed, overall average %, highest score %, most recent score, and delta compared to the previous attempt.
   - Native Canvas charts:
     - Subject-wise average bar chart.
     - Chronological score progression trendline.
     - Chapter syllabus completion gauge across all 6 subjects.
   - Transparent rule-based recommendations (e.g., flagging chapters lacking PYQs or subjects with declining score trends).
7. **Settings, Customization & Data Portability**:
   - Edit student name.
   - Theme toggle (System default, Crisp Light, Deep Navy Dark).
   - Daily 4:30 PM reminder notification toggle and time picker.
   - Offline JSON Export & Import via Android Storage Access Framework (SAF).
   - Secure factory reset with dual-confirmation dialog.

### Visual Identity & Theme

- **Aesthetic Direction**: Crisp, modern academic workspace — clean, professional, distraction-free.
- **Color Palette**:
  - Primary: Deep Academic Navy (`#1E293B` / `#0F172A`)
  - Accent / Focus: Electric Cobalt (`#2563EB`) & Soft Violet (`#7C3AED`)
  - Background Light: Clean Off-White (`#F8FAFC`), Surface: Pure White (`#FFFFFF`)
  - Background Dark: Midnight Slate (`#0B0F19`), Surface Dark: Dark Slate (`#1E2230`)
  - Success: Emerald Green (`#10B981`)
  - Warning / Overdue: Warm Amber (`#F59E0B`) & Crimson (`#EF4444`)
- **Typography & Rhythm**:
  - Clean sans-serif hierarchy with bold headers (`headlineMedium`), crisp labels (`labelLarge`), and readable body copy (`bodyMedium`).
  - 48dp minimum interactive touch targets across all checkboxes, chips, and buttons.
  - Full edge-to-edge support with `safeDrawing` and navigation bar insets.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Local-First Room Database vs Cloud Auth**:
  - *Chosen Approach*: Pure device-local SQLite via Android Room with KSP code generation and Flow reactivity.
  - *Why*: Strict user privacy, zero internet latency, works 100% offline in airplane mode, no sign-in barriers, and zero risk of external data leakage.
  - *Alternatives Considered*: Firebase Firestore was rejected because the user explicitly requested no accounts, no cloud sync, and full offline autonomy.
- **Decision 2: Preference Storage via DataStore & SharedPreferences**:
  - *Chosen Approach*: Jetpack DataStore / SharedPreferences for lightweight onboarding flags, user name, dark mode toggle, and notification timestamps.
  - *Why*: Instant synchronous/cached read at cold startup to prevent any screen flicker between Onboarding and Dashboard.
- **Decision 3: Native Canvas Visualizations vs Heavy Chart Libraries**:
  - *Chosen Approach*: Clean, custom Jetpack Compose Canvas charts for bar charts and score progression trends.
  - *Why*: Eliminates bloated third-party dependencies, prevents AGP/Kotlin version conflicts, and ensures ultra-fast rendering on hardware with limited resources like the Redmi 9 Power.
- **Decision 4: Inexact Alarm / WorkManager Notifications**:
  - *Chosen Approach*: Standard Android Notification Channel with Android 13+ runtime permission check (`POST_NOTIFICATIONS`) and inexact AlarmManager / WorkManager.
  - *Why*: Guarantees reliable delivery without requiring hazardous `USE_EXACT_ALARM` permissions that trigger Play Store/MIUI background battery kills.

---

## 4. Technical Architecture & Data Strategy

### System Architecture & Component Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           StudyFlow 10 (M3 UI)                              │
│                                                                             │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌─────────────────┐  │
│  │  Dashboard   │  │   Homework   │  │   Chapters   │  │ Question Papers │  │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘  └────────┬────────┘  │
│         │                 │                 │                   │           │
│         │          ┌──────┴───────┐  ┌──────┴───────┐           │           │
│         └─────────►│  Analytics   │  │   Settings   │◄──────────┘           │
│                    └──────┬───────┘  └──────┬───────┘                       │
└───────────────────────────┼─────────────────┼───────────────────────────────┘
                            │                 │
                            ▼                 ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                      StudyFlowViewModel & StateFlow                         │
│   • studentProfileState   • homeworkFilterState   • selectedSubjectState    │
│   • dashboardMetricsFlow  • chapterProgressFlow   • scoreAnalyticsFlow      │
└─────────────────────────────────────┬───────────────────────────────────────┘
                                      │
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                              Repository Layer                               │
│  ┌───────────────────────────────┐   ┌───────────────────────────────────┐  │
│  │      StudyFlowRepository      │   │     UserPreferencesRepository     │  │
│  └──────────────┬────────────────┘   └──────────────────┬────────────────┘  │
└─────────────────┼───────────────────────────────────────┼───────────────────┘
                  │                                       │
                  ▼                                       ▼
┌─────────────────────────────────────┐ ┌─────────────────────────────────────┐
│        Room SQLite Database         │ │       DataStore Preferences         │
│  • homework_table                   │ │  • user_name                        │
│  • subjects_table                   │ │  • is_onboarded                     │
│  • chapters_table                   │ │  • theme_mode                       │
│  • chapter_tasks_table (7 items)    │ │  • reminder_enabled                 │
│  • question_papers_table            │ │  • reminder_time                    │
└─────────────────────────────────────┘ └─────────────────────────────────────┘
```

### Data Model & Entities

1. **`HomeworkEntity`**:
   - `id: Long` (PrimaryKey, autoGenerate = true)
   - `title: String`
   - `subject: String` (e.g., "Mathematics", "Science", etc.)
   - `notes: String`
   - `dueDate: Long?` (epoch millis)
   - `createdAt: Long` (epoch millis)
   - `isCompleted: Boolean`
2. **`SubjectEntity`**:
   - `id: String` (PrimaryKey, e.g., "MATH", "SCI", "SST", "ENG", "HIN", "AI")
   - `name: String`
   - `displayOrder: Int`
3. **`ChapterEntity`**:
   - `id: Long` (PrimaryKey, autoGenerate = true)
   - `subjectId: String`
   - `chapterNumber: Int?`
   - `name: String`
   - `notes: String`
   - `createdAt: Long`
4. **`ChapterTaskEntity`**:
   - `id: Long` (PrimaryKey, autoGenerate = true)
   - `chapterId: Long` (ForeignKey -> ChapterEntity.id, onDelete = CASCADE)
   - `taskType: String` (NCERT_READING, LECTURE, NCERT_QUESTIONS, PYQ, CBT_QUESTIONS, HARD_LEVEL, SAMPLE_PAPER)
   - `isCompleted: Boolean`
   - `completedAt: Long?`
5. **`QuestionPaperEntity`**:
   - `id: Long` (PrimaryKey, autoGenerate = true)
   - `subjectId: String`
   - `paperName: String`
   - `maxMarks: Double`
   - `obtainedMarks: Double?`
   - `attemptDate: Long` (epoch millis)
   - `durationMinutes: Int?`
   - `notes: String`
   - `status: String` (NOT_STARTED, IN_PROGRESS, COMPLETED)

### Verification & Delivery Plan

1. Update `metadata.json` and Android strings with the verified application name `StudyFlow 10` and package namespace `com.pranav.studyflow10`.
2. Configure Android Room database with KSP code generator and DAO interfaces.
3. Build complete UI: Welcome screen, Dashboard, Homework Manager, 6-Subject Chapter Tracker with all 7 tasks, Question Paper Manager with scoring validation, Performance Analytics with Canvas charts, and functional Settings with JSON backup/restore.
4. Execute `compile_applet` to produce the genuine `app-debug.apk`.
5. Verify package integrity, offline capabilities, and provide clear step-by-step sideloading instructions for the Xiaomi Redmi 9 Power.
